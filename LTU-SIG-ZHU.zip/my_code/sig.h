/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-19     liuwei       the first version
 */
#ifndef MY_CODE_SIG_H_
#define MY_CODE_SIG_H_


#endif /* MY_CODE_SIG_H_ */

#define  EVE_FLAG_PEACK_SIG2  2


void Sig();

void Set_Start_SIG(rt_uint16_t  Prescaler, rt_uint16_t cnt);

void high_period(void);
void low_period(void);


void Thread_Sig2(void);
void IPC_Sig2_Init(void);
void Coed_Data(rt_bool_t *data);

void Enable_Topo(void);
void Enable_Time(void);
