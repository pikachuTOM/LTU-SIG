/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */

#include "board.h"
#include "init.h"
#include "cfft.h"
#include "ai.h"
#include "dev_param.h"
#include "sample_control.h"

//extern
extern q15_t Frec_threshold;
extern q15_t Frec_threshold_2;
extern T_Device_Para global_devpa;

//缓冲
q15_t dsp_buff[SAMPLING_POINTS];  //adc的缓冲
uint16_t adc_buf[128*10];  //从dsp_buff 稀释出每周波128点
uint16_t i_num = 0;        //行标识 0-1279

//拓扑soe 缓冲相关
q15_t topo_value[5];                      //傅里叶变换后的数据
//ipc
struct rt_event cfft_event;
struct rt_messagequeue mq_topo;           //消息队列结构体
uint8_t msg_pool_topo[SIZE_PER_SOE_MQ*SOE_BUF_LEN];    //消息池


//使能 拓扑接收和 对时信号接收
rt_bool_t enable_topo_recv = RT_TRUE;
rt_bool_t enable_time_recv = RT_FALSE;

rt_bool_t enable_stop_topo_rec = RT_FALSE;    //topo debug
rt_bool_t just_record = RT_FALSE;



extern rt_bool_t mb_control_sg_topo;

/*  DMA 中断回调，这里 每 5ms, 1/4周波中断一次
 *
 * */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    HAL_TIM_Base_Stop_IT(&htim6);
    HAL_ADC_Stop_DMA(&hadc1);

    if(enable_time_recv)
        rt_event_send(&cfft_event, CPLT_DMA_EVE_FLAG);//通知检测线程

    if(enable_topo_recv)
        Pick32out5000(1);   //稀疏出数据给 cfft用

    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dsp_buff, SAMPLING_POINTS);
    HAL_TIM_Base_Start_IT(&htim6);
}

// dma接收     半 中断
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if(enable_time_recv)
        rt_event_send(&cfft_event, HALF_DMA_EVE_FLAG);//通知检测线程
    if(enable_topo_recv)
        Pick32out5000(0);   //稀疏出数据给 cfft用
}



void Cfft_Thread(void)
{
    rt_uint32_t e;
    uint8_t buf[SIZE_PER_SOE_MQ];

    //设置参数
    Frec_threshold = global_devpa.cff_threshold[0];
    Frec_threshold_2 = global_devpa.cff_threshold[1];

#define  enable_send_debug 0
#if enable_send_debug
    uint8_t debug_continue_send_topo = 0;
#endif

    //4、TIM  ADC DMA  初始化                                //数据个数，不是字节数
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dsp_buff, SAMPLING_POINTS);
  HAL_TIM_Base_Start_IT(&htim6);

    while(1){
        if(RT_EOK ==  rt_event_recv(&cfft_event, (1|2|4|8|16|32|64|128|256|512), RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, -1, &e)){
            if (((e-1) & e )) {//判断是否是2的n次方
                rt_kprintf("eErr:0x%x\r\n",e);
                continue;
            }

#if enable_send_debug
            if (50==debug_continue_send_topo ++)
            {
                //rt_mq_send(&mq_topo, buf, SIZE_PER_SOE_MQ);
                debug_continue_send_topo = 0;
                goto SEND_AGAIN;
            }
#endif

           if(!Cfft(index_2_(e)))  //傅里叶 变换
           {
               rt_kprintf("soe\n");
               if (mb_control_sg_topo)
               {
                   Get_Time_8(&buf[0]);
                   rt_memcpy(&buf[8], topo_value, 5*2);
                   buf[18] = 0x01;   //拓扑soe
                   rt_mq_send(&mq_topo, buf, SIZE_PER_SOE_MQ);
                   rt_memset(topo_value, 0, 10);
               }

            }else{  //no topo
                if(just_record)
                {    //没有拓扑的时候停止
                   topo_stop(index_2_(e));
                }
            }
        }else{
            rt_kprintf("ce\n");
        }
    }
}

/*    dma half和cplt中断 都会调用
 *   从前5000个后5000个中 各稀释32个,共 64个点, 每10ms
 * */
void Pick32out5000(uint8_t half)
{
    /*                 i=  0    1     2       3    4        5 6 7 8   9......63
     *       dspbufindex=  0+0 156*1 156*2  156*3   156*4+1      156*8+2
     * */
    uint8_t i;
    for (i = 0; i < 32; ++i) {

        adc_buf[i_num++] = dsp_buff[5000*half+ 156*i + (i/4) ];
       // rt_kprintf("156* %d +%d = %d\n",i,i/4,5000*half+ 156*i + (i/4) );
    }
    if(half && (!(i_num%128)) ){
        rt_event_send(&cfft_event, 1<<(i_num/128-1));   //1<<(0123456789)
        i_num %= 1280;   //只用在 i_num 等于1280时 才需要归零
    }
}

/*事件集 初始化
 *
 * */
void IPC_ai_Init(void)
{
    rt_err_t result;
    result =  rt_event_init(&cfft_event, "cffteve", RT_IPC_FLAG_FIFO);
    if(RT_EOK != result){
         rt_kprintf("CfftEveErr\r\n");
    }
    rt_mq_init(&mq_topo, "topo", msg_pool_topo, SIZE_PER_SOE_MQ, SIZE_PER_SOE_MQ*SOE_BUF_LEN, RT_IPC_FLAG_FIFO);

}



/* 求以2为底 x的对数 */
uint8_t index_2_(uint16_t x)
{
    uint8_t i = 0;
    while(1){
        if ( x == 1) {
            return i;
        }else {
            x = x >> 1;
            i++;
        }
    }
}


/*
    debug
*/
void topo_stop(uint8_t index)
{
    rt_kprintf("topo check stop!!!, index is: %d\n", index);

    //0 1 2 3456789 ,假如 index = 2, 实际是从 3->4->...9->0...->2
    uint16_t i = (index+1) *128;


    for (; i < 1280; ++i) {
        rt_kprintf("%d ",adc_buf[i]);
    }


    for (i = 0; i < ((index+1) *128) ; ++i) {
        rt_kprintf("%d ", adc_buf[i]);
    }
    rt_kprintf("\n");

    while(1){
      rt_thread_mdelay(10000);
    }
}



#if 1
//
//打印padcbuf
void padcbuf(void)
{
    //uint16_t adc_buf[128*10];
    uint16_t i;
    rt_kprintf("adc_buf:\n");
    for (i = 0; i < 1280; ++i) {
        rt_kprintf("%d ", adc_buf[i]);
    }
    rt_kprintf("\nadc_buf end\n");

}
FINSH_FUNCTION_EXPORT(padcbuf, padcbuf);
MSH_CMD_EXPORT(padcbuf, padcbuf);
#endif

/*使能 检测到topo停止 adc并打印*/
void esat(void)
{
    enable_stop_topo_rec = RT_TRUE;

}
FINSH_FUNCTION_EXPORT(esat, enable stop adc after get a topo);
MSH_CMD_EXPORT(esat, enable stop adc after get a topo);

void stan(void){
    just_record = RT_TRUE;
}
FINSH_FUNCTION_EXPORT(stan,  stop topo adc now);
MSH_CMD_EXPORT(stan, stop topo adc now);

