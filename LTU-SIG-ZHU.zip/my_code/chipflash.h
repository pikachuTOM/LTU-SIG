/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-18     94793       the first version
 */




rt_uint8_t My_Flash_Erase(uint32_t Page, uint32_t NbPages);
rt_uint8_t My_Flash_Program(uint32_t addr, void *pdata, rt_uint16_t size);
