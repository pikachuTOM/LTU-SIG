/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-18     94793       the first version
 */

#include "board.h"
#include "chipflash.h"

#if 0   //例子
//写入到flash
            if(HAL_OK != HAL_FLASH_Unlock()){
                    rt_kprintf("Fla Unlo\n");
            }
            //擦除
            if(0!= My_Flash_Erase(DEV_PARA_HEAD, 1) ){
                    rt_kprintf("DevParErase\n");
            }
            //写入
            if(0!=My_Flash_Program(DEV_PARA_HEAD*FLASH_SECTOR_SIZE, &dev_par_data, sizeof(Dev_Par_T))){
                    rt_kprintf("DevParProg\n");
            }
            HAL_FLASH_Lock();

#endif

/**  flash 擦除
 * @brief
 * @param[]
 * @return   返回0表示擦除成功，1表示失败
 **/
rt_uint8_t My_Flash_Erase(uint32_t Page, uint32_t NbPages)
{
        FLASH_EraseInitTypeDef flash_erase;
        uint32_t page_error;
        //HAL_StatusTypeDef result;
        flash_erase.TypeErase = FLASH_TYPEERASE_PAGES;
        flash_erase.Page = Page;   //页
        flash_erase.NbPages = NbPages;  //每个page 2kB

        //result = HAL_FLASHEx_Erase(&flash_erase, &page_error);
        if(HAL_OK != HAL_FLASHEx_Erase(&flash_erase, &page_error)){
                return 1;
        }else{
                return 0;
        }
}

/**  flash 写入
 * @brief
 * @param[]  flash的地址（需要自己乘 2K），数据指针，数据的字节数
 * @return   返回0表示写入成功，1表示失败
 **/

rt_uint8_t My_Flash_Program(uint32_t addr, void *pdata, rt_uint16_t size)
{
        uint32_t Flash_Addr;       //flash实际的地址
        uint64_t Data_64;          //必须一次写入8B
        uint64_t *p = pdata;
        rt_uint16_t size_I, size_D, i;
        size_I = size/8;   //取整//size 除以8 取整和余
        size_D = size%8;   //取余

        //写入整数
        if(0!=size_I){
                for(i=0;i<size_I; i++){
                        Flash_Addr = addr +8*i;   //地址
                        Data_64 = *p;             //数据
                        if(HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, Flash_Addr, Data_64)){
                                return 1;
                        }
                        p++;
                }
      }
        //写入余数,  p在最后一次已经指向了余数部分，不足8个字节
        if(0!=size_D){
                rt_uint8_t *p1 = (rt_uint8_t *)p;
                Data_64 = 0;
                for(i=0;i<size_D;i++){
                        Data_64 +=  (*p1)<<(8*i);   //组合数据    Data_64 += (*(data_8+i)) * 8*i;
                        p1++;
                }
                //写入
                Flash_Addr = addr +size_I*8;
                if(HAL_OK !=HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, Flash_Addr, Data_64)){
                        return 1;
                }
        }
        return 0;
}
