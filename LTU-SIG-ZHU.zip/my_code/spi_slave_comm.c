/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-05     liuwei       the first version
 */

#include "board.h"
#include "spi_slave_comm.h"
#include "sig.h"
#include "chipflash.h"
#include "app_param.h"
#include "ai.h"
#include "universal_api.h"
#include "dev_param.h"
#include "RX8025T.h"

extern RTC_HandleTypeDef hrtc;
extern SPI_HandleTypeDef hspi3;
extern DMA_HandleTypeDef hdma_spi3_rx;
extern DMA_HandleTypeDef hdma_spi3_tx;
extern T_Device_Para global_devpa;

extern struct rt_messagequeue mq_topo;
extern rt_bool_t sig2_enable;
extern rt_bool_t sig2_code[32];
extern rt_bool_t enable_time_send;
extern rt_bool_t enable_topo_send;

//IPC 消息初始化
struct rt_messagequeue mq_spi_comm;
uint8_t  msg_pool_spi_comm[sizeof(T_msg_spi)*10];

struct rt_event spi3_rx_event;

// 实际的接收缓冲和发送缓冲
uint8_t spi3_rx_buf[RX_BUF_LEN];   //接收缓冲区
uint8_t spi3_tx_buf[TX_BUF_LEN]; //= {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x10};    //发送缓冲

//sig板升级相关
uint16_t progress;   //进度条

//MB控制SG关闭拓扑识别相关
rt_bool_t mb_control_sg_topo = RT_FALSE;//RT_TRUE;


// spi3 dma half接收中断回调
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
    //if (&hspi3 == hspi) {
       // rt_kprintf("spi3 dma rx finish\n");
       // rt_event_send(&spi3_rx_event, spi3_RX_EVENT_FLAG); //通知接收处理线程
   // }

}
//spi3 dma 发送完成中断回调
void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
   // if (&hspi3 == hspi) {
      // rt_kprintf("spi3 dma tx finish\n");
      // HAL_SPI_Receive_DMA(&hspi3, spi3_rx_buf, RX_DATA_LEN);
    //}
}
//spi 3 dma 发送/接收  回调
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    //rt_kprintf("txrx\n");
    if (&hspi3 == hspi) {
        rt_event_send(&spi3_rx_event, spi3_RX_EVENT_FLAG); //通知接收处理线程
    }

}

//从机 spi 线程  THREAD
void Spi_Slave_Recieve_Thread()
{
    rt_uint32_t e;
    uint8_t cmd;

    while(1){
        if(RT_EOK ==  rt_event_recv(&spi3_rx_event, spi3_RX_EVENT_FLAG, RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, -1, &e)){
//接收
            rt_memcpy(spi3_tx_buf, spi3_rx_buf, DATA_FRAME_LENGTH);

            cmd =  Message_Analysis();//检测 包头包尾和 校验，并返回 cmd,否则返回 0
            //rt_kprintf("cmd=%x\n", cmd);
            switch (cmd) {
                case SLAVE_REBOOT:
                    rt_kprintf("SLAVE REBOOT\n");
                    rt_memset(spi3_rx_buf, 0, 15);                               //清空接收
                    Start_Spi3_DMA_Receive();                                    //重启接收中断 必须
                    rt_hw_cpu_reset();  //重启命令
                    break;

                case SLAVE_Topological_Signal:
                    rt_memset(spi3_rx_buf, 0, 15);                               //清空接收
                    Start_Spi3_DMA_Receive();                                    //重启接收中断 必须
                    if (enable_topo_send) {
                        rt_kprintf("SLAVE_Topological_Signal\n");
                        Sig(); //发拓扑信号
                    } else if(enable_time_send){

                        sig2_enable = RT_TRUE;
                        rt_kprintf("SLAVE_Time_Signal\n");
                    }

                    break;

                case SLAVE_Time_Signal:
                    Slave_Time_Proccess();  //切换 功能，修改对时编码

                    break;
                case SLAVE_UPDATE:
                    Slave_Update_Process();
                    break;
                case SLAVE_READ_APP_PARAM:
                    Read_RunApp_Param_Process();
                    break;
                case SLAVE_READ_TOPO:
                    Read_Topo_Proccess();
                    break;
                case SLAVE_CORRECT_TIME:
                    Slave_Correct_Time_Proccess();
                    break;
                case SLAVE_CFFT_THRESOLD:
                    Slave_Set_Cfft_Proccess();
                    break;
                case READ_SLAVE_TIME:
                    Slave_Read_Time_Proccess();   //读从机时间
                default:
                    rt_memset(spi3_rx_buf, 0, 15);                               //清空接收
                    Start_Spi3_DMA_Receive();
                    //rt_kprintf("Unknown command 0x%x received\n", cmd);
                    break;
            }

        }
    }
}
// ipc 初始化
void IPC_spi_comm_init()
{
    rt_mq_init(&mq_spi_comm, "spi_comm", msg_pool_spi_comm, sizeof(T_msg_spi), sizeof(msg_pool_spi_comm), RT_IPC_FLAG_FIFO);
    rt_event_init(&spi3_rx_event, "spi3 rx", RT_IPC_FLAG_FIFO);

}
//启动 spi3 dma 接收
void Start_Spi3_DMA_Receive()
{
    if(HAL_OK !=HAL_SPI_TransmitReceive_DMA(&hspi3, spi3_tx_buf, spi3_rx_buf,RX_DATA_LEN)){

    }
}


/*********私有协议相关********/
//生成 八位的 校验 并填充
//  采用异或 校验
uint8_t Create_Check_Code(uint8_t *data, uint8_t size)
{
    uint8_t i, result;
    result = data[0];
    for (i = 1; i < size; ++i) {
        result ^= data[i];
    }
    return result;
}

// 包头 包尾 异或 ,命令码 检测
//正常返回 存在的命令码 ，失败返回 0
uint8_t Message_Analysis()
{

    if ((spi3_rx_buf[INDEX_HEAD]!= MESSAGE_HEAD)||(spi3_rx_buf[INDEX_STOP]!= MESSAGE_TAIL)) {


#if 0
        uint8_t i;
        rt_kprintf("MESSAGE head and tail error\n");
            for (i = 0; i < RX_BUF_LEN; ++i) {
                rt_kprintf("%x ", spi3_rx_buf[i]);
            }
            rt_kprintf("\n");
#endif
        return 0;
    }
    if (Create_Check_Code(spi3_rx_buf, INDEX_Frame_Check) != spi3_rx_buf[INDEX_Frame_Check]){

#if 0
        uint8_t i;
        rt_kprintf("check XOR error \n");
            for (i = 0; i < RX_BUF_LEN; ++i) {
                rt_kprintf("%x ", spi3_rx_buf[i]);
            }
            rt_kprintf("\n");
#endif
        return 0;
    }
    return spi3_rx_buf[INDEX_COMM];   //返回命令码
}
//组织包头和包尾
void Create_Head_Tail(void)
{
    rt_memset(spi3_tx_buf, 0, TX_BUF_LEN);//先清除 发送缓冲中所有的内容   tx_buf[TX_BUF_LEN]
    spi3_tx_buf[INDEX_HEAD] = MESSAGE_HEAD;   //填充包头
    spi3_tx_buf[INDEX_STOP] = MESSAGE_TAIL;   //填充停止位
}
//填充命令字 长度和数据
rt_bool_t Create_Comm_Len_Data(uint8_t comm, uint8_t *data, uint8_t data_size)
{
    if (data_size >MAX_DATA_SIZE) {
        rt_kprintf("data_size >MAX_DATA_SIZE\n");
        return RT_FALSE;
    }
    spi3_tx_buf[INDEX_COMM] = comm;                        //填充 命令字
    if ((data != RT_NULL) && (data_size!=0)) {
        spi3_tx_buf[INDEX_LEN] = data_size;                    //填充有效数据的长度
        rt_memcpy(&spi3_tx_buf[INDEX_DATA] , data, data_size); //填充 数据
    }

    return RT_TRUE;
}

/**************************************************************************/
//从机 升级 处理函数       spi3_rx_buf
rt_bool_t Slave_Update_Process()
{
    uint32_t flow_num;
    uint8_t error_cnt;
    /*********************************************************/
    if(SLAVE_READY_UPGRADE ==  spi3_rx_buf[INDEX_CTL] ){
        rt_memcpy(&flow_num, &spi3_rx_buf[INDEX_DATA], 4);
        rt_kprintf("slave ready upgrade , app_size=%d\n", flow_num);
        progress = 0; //进度条归零
        error_cnt = 4;
CHIP_FLASH_UNLOCK_AGAIN:
        if(HAL_OK != HAL_FLASH_Unlock()){
            if (error_cnt--) {
                rt_kprintf("FLASHUnlock1\n");
                goto CHIP_FLASH_UNLOCK_AGAIN;
            }else {
                rt_kprintf("slave upgrade failed,FLASH cannot Unlock");
                rt_memset(spi3_rx_buf, 0, 32);              //清空接收
                Start_Spi3_DMA_Receive();
                return RT_FALSE;   //升级失败 直接退出
            }
        }
        error_cnt = 4;
CHIP_FLASH_ERASE_AGAIN:        //擦除
        if(My_Flash_Erase(UPGRADE_DATA_SUBNUM, (flow_num/SUB_SIZE_CHIPFLASH+1+1))){
            if (error_cnt--) {
                rt_kprintf("Flash_Erase1 \n");
                goto CHIP_FLASH_ERASE_AGAIN;
            }else {
                HAL_FLASH_Lock();
                rt_kprintf("slave upgrade failed,Flash cannot Erase1\n");
                rt_memset(spi3_rx_buf, 0, 32);              //清空接收
                Start_Spi3_DMA_Receive();
                return RT_FALSE;   //升级失败 直接退出
            }
        }
        HAL_FLASH_Lock();
        rt_memset(spi3_rx_buf, 0, 32);              //清空接收
        Start_Spi3_DMA_Receive();                    //重启接收后再 反转IO
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);
        return RT_TRUE;
        /*********************************************************/
    }else if(UPGRADE_DATA == spi3_rx_buf[INDEX_CTL]){
        if (!((progress++)% 100)) {
            rt_kprintf("-");//进度条
        }
        rt_memcpy(&flow_num, &spi3_rx_buf[INDEX_DATA], 4);    //获取当前字节数
        error_cnt = 3;
FLASH_UNLOCK_AGAIN:
            if(HAL_OK != HAL_FLASH_Unlock()){
                if (error_cnt--) {
                    rt_kprintf("FLASHUnlock2\n");
                    goto FLASH_UNLOCK_AGAIN;
                }else {

                    rt_kprintf("slave upgrade failed,FLASH cannot Unlock2\n");
                    rt_memset(spi3_rx_buf, 0, 32);              //清空接收
                    Start_Spi3_DMA_Receive();
                    return RT_FALSE;   //升级失败 直接
                }
            }
            if(My_Flash_Program(UPGRADE_APP_PARA_ADDR +flow_num, &spi3_rx_buf[INDEX_DATA+4], 16)){
                HAL_FLASH_Lock();
                rt_kprintf("slave upgrade failed,Program error\n");
                rt_memset(spi3_rx_buf, 0, 32);              //清空接收
                Start_Spi3_DMA_Receive();
                return RT_FALSE;   //升级失败 直接
            }
            HAL_FLASH_Lock();
        }

        rt_memset(spi3_rx_buf, 0, 32);               //清空接收
        Start_Spi3_DMA_Receive();                    //重启接收后
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);       //反转IO

        return RT_TRUE;
    }
// 读取 app版本信息 处理函数
rt_bool_t Read_RunApp_Param_Process()
{
    rt_kprintf("read app param\n");
    //uint8_t i;
    uint8_t SVHV_data[16];
    App_Param *p;
   //获取sv和hv
    p = (App_Param  *)(0x08004700);
    rt_memcpy(&SVHV_data[0], p->SV, 8);
    rt_memcpy(&SVHV_data[8], p->HV, 8);
    //填充 txbuff
    Create_Head_Tail();
    Create_Comm_Len_Data(SLAVE_READ_APP_PARAM, SVHV_data, 16);


    spi3_tx_buf[INDEX_Frame_Check] = Create_Check_Code(spi3_tx_buf, INDEX_Frame_Check);
    /*for (i = 0; i < RX_BUF_LEN; ++i) {
        rt_kprintf("%x ", spi3_tx_buf[i]);
    }rt_kprintf("\n");*/

    rt_memset(spi3_rx_buf, 0, 32);              //清空接收
    Start_Spi3_DMA_Receive();

    rt_thread_mdelay(10);
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);

    return 0;

}
/*读取 拓扑信息
 *
 * */
rt_bool_t Read_Topo_Proccess()
{
    //rt_kprintf("TP\n");
    uint8_t  buf[SIZE_PER_SOE_MQ+4];  //时间 + 5个量，2个门槛值
    if (spi3_rx_buf[INDEX_DATA] == 0x01) {  //使能topo
        rt_kprintf("enable topo\n");
        mb_control_sg_topo = RT_TRUE;
    } else if(spi3_rx_buf[INDEX_DATA] == 0x02){  //关闭topo
        rt_kprintf("disable topo\n");
        mb_control_sg_topo = RT_FALSE;
    }
    //填充 txbuff
    Create_Head_Tail();
    if (mb_control_sg_topo)   //使能了拓扑，就要查看消息，如果有就发给mb没有就发没有
    {
        if(RT_EOK == rt_mq_recv(&mq_topo, buf, SIZE_PER_SOE_MQ, 0))
        {
            if (0x01==buf[18]) {
                spi3_tx_buf[INDEX_CTL] = 0x01;   //0x01代表有 拓扑信息//
                rt_memcpy(&buf[SIZE_PER_SOE_MQ-1], global_devpa.cff_threshold, 4);   //添加门槛值
                Create_Comm_Len_Data(SLAVE_READ_TOPO, buf, SIZE_PER_SOE_MQ+4-1);
                rt_kprintf("topo soe\n");

            }else if (0x02==buf[18]){
                spi3_tx_buf[INDEX_CTL] = 0x02;
                Create_Comm_Len_Data(SLAVE_READ_TOPO, buf, 8+4);
                rt_kprintf("time soe\n");
            }
        }else {
            spi3_tx_buf[INDEX_CTL] = 0x00;   //无
            Create_Comm_Len_Data(SLAVE_READ_TOPO, NULL, 0);
        }
    }
    else
    {
        for (uint8_t i = 0; i < 3; ++i)
        {
            rt_mq_recv(&mq_topo, buf, SIZE_PER_SOE_MQ, 20);
        }
        spi3_tx_buf[INDEX_CTL] = 0x00;   //无
        Create_Comm_Len_Data(SLAVE_READ_TOPO, NULL, 0);

    }
    spi3_tx_buf[INDEX_Frame_Check] = Create_Check_Code(spi3_tx_buf, INDEX_Frame_Check);

    /*for (i = 0; i < RX_BUF_LEN; ++i) {
        rt_kprintf("%x ", spi3_tx_buf[i]);
    }rt_kprintf("\n");
*/

    rt_memset(spi3_rx_buf, 0, 32);              //清空接收
    Start_Spi3_DMA_Receive();

    rt_thread_mdelay(10);
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);

    return RT_TRUE;
}

//从机对时
rt_bool_t Slave_Correct_Time_Proccess()
{
    rt_kprintf("SLAVE_CORRECT_TIME\n");
    Uint8_Correct_Time(&spi3_rx_buf[INDEX_DATA]);  //RTC对时
    Set_8025t(&spi3_rx_buf[INDEX_DATA]);           //8025对时

    rt_memset(spi3_rx_buf, 0, 32);                 //清空接收
    Start_Spi3_DMA_Receive();

    rt_thread_mdelay(10);
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);
    return 0;

}
//设置 cfft 门槛值
rt_bool_t Slave_Set_Cfft_Proccess()
{
    rt_kprintf("SLAVE_CFFT_THRESOLD\n");
    //global_devpa.cff_threshold[]
    rt_memcpy(&global_devpa.cff_threshold[0], &spi3_rx_buf[INDEX_DATA], sizeof(global_devpa.cff_threshold));

    Save_Dev_Para();
    rt_memset(spi3_rx_buf, 0, 32);              //清空接收
    Start_Spi3_DMA_Receive();

    rt_thread_mdelay(10);
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);
    return 0;

}
// 修改对时或 拓扑功能，修改对时编码
rt_bool_t Slave_Time_Proccess()
{
    if (spi3_rx_buf[INDEX_DATA] == 0x01) {   //切换功能
        if (0x01==spi3_rx_buf[INDEX_DATA+1]) {   //切换成对时信号
            Enable_Time();
        } else if(0x02==spi3_rx_buf[INDEX_DATA+1]){  //切换成拓扑信号
            Enable_Topo();
        }

    } else if(spi3_rx_buf[INDEX_DATA] == 0x02){   //修改编码
         //spi3_rx_buf[INDEX_DATA+1]
        uint32_t *p = (uint32_t *)(&spi3_rx_buf[INDEX_DATA+1]);
        uint8_t i;
        rt_kprintf("new code:");
        for (i = 0; i < 32; ++i) {
            if (  (*p)& (1<<i)  ) {
                sig2_code[i] = 1;
                rt_kprintf("1");
            }else {
                sig2_code[i] = 0;
                rt_kprintf("0");
            }
        }
        rt_kprintf("\n");
    }
    rt_memset(spi3_rx_buf, 0, 15);                               //清空接收
    Start_Spi3_DMA_Receive();

    return 0;
}

/*MB 从 SG板读取时间*/
rt_bool_t Slave_Read_Time_Proccess(void)
{
        rt_kprintf("READ_SLAVE_TIME\n");
        uint8_t time_buf[8];
        Get_Time_8(time_buf);  //从RTC获取时间

        Create_Head_Tail();//填充 头尾

        Create_Comm_Len_Data(READ_SLAVE_TIME, time_buf, 8);  //填充  命令字 数据 长度  三个
        spi3_tx_buf[INDEX_Frame_Check] = Create_Check_Code(spi3_tx_buf, INDEX_Frame_Check);  //填充校验码

        /*for (i = 0; i < RX_BUF_LEN; ++i) {
            rt_kprintf("%x ", spi3_tx_buf[i]);
        }rt_kprintf("\n");
        */

        rt_memset(spi3_rx_buf, 0, 32);              //清空接收
        Start_Spi3_DMA_Receive();

        rt_thread_mdelay(10);
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);

        return RT_TRUE;

}



