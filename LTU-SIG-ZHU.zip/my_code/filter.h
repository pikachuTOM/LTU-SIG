/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-13     liuwei       the first version
 */
#ifndef MY_CODE_FILTER_H_
#define MY_CODE_FILTER_H_

#endif /* MY_CODE_FILTER_H_ */

//滤波相关
#define   TEST_LENGTH_SAMPLES       (SIG_CODE_LEN+SIG2_MORE_BUF_POINT)      //参与滤波计算的点数
#define   BLOCK_SIZE                200                                    //每次计算200个点
#define   CNT_COMPUTE  (TEST_LENGTH_SAMPLES/BLOCK_SIZE)  //
#define   NUM_TAPS          (127+1)  //127阶 ，但是系数是128个

//解码相关  波的间隔和宽度
//#define   FIRST_PEAK_THRESOLD         50          //寻找第一位 波峰时的门槛值
//#define   FIND_FIRST_PEAK_NUM         400         //只在前400个点里找，如果没有认为解码失败，因为剩下的点数不够32位编码的了

#define   DISTANCE_OF_2PEAK           200         //对时信号两个 位之间的理论距离
#define   VAGUE_DISTANCEPEAK          50           //200上下浮动50

#define   WIDTH_OF_1PEAK              73          //73, 对时信号一个位波峰的大约宽度
#define   VAGUE_WIDTHPEAK             3           //73上下浮动3

#include "dev_param.h"
extern T_Device_Para global_devpa;

//寻找第一个波峰的 数据窗
#define   PEAK_WINDOW_INTERVAL    10   //数据窗间隔
#define   PEAK_WINDOW_LEN         5    //数据窗长度
#define   PEAK_WINDOW_STEP        5    //数据窗每次移动的 步长
#define   PEAK_WINDOW_THRESOLD    (global_devpa.win1_threshold[1])//50    //门槛值 ，差值  20->80
#define   PEAK_THRESOLD_COUNT     1      //一个数据窗内 超过 1个突变量就算 启动录波

//第二个波峰的 数据窗
#define   PEAK2_WINDOW_INTERVAL    13   //数据窗间隔
#define   PEAK2_WINDOW_THRESOLD    (global_devpa.win1_threshold[2])//5    //门槛值 ，差值 5->80
#define   PEAK2_THRESOLD_COUNT     1      //一个数据窗内 超过 n个突变量就算 启动录波



void fir_u16_bp(uint16_t sig2_start_index);
rt_bool_t Sig2_Decode(uint32_t *sig2code );

rt_bool_t Win1_Check_Filtedata(uint16_t a, uint16_t b);
uint16_t Find_MAX_index(uint16_t a);
rt_bool_t Win2_Check_Filtedata(uint16_t index);
