/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */
#include "board.h"
#include "spi_slave_comm.h"


extern DMA_HandleTypeDef hdma_adc1;
extern DMA_HandleTypeDef hdma_spi3_rx;
extern DMA_HandleTypeDef hdma_spi3_tx;
extern TIM_HandleTypeDef htim7;

void DMA1_Channel1_IRQHandler(void)   //模拟量中断
{

   // rt_kprintf("1\r\n");
  HAL_DMA_IRQHandler(&hdma_adc1);

}
// 拓扑信号发生
void TIM7_IRQHandler(void)
{

    //反转
  HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_1);
  HAL_TIM_IRQHandler(&htim7);

}
// GPIO 上升沿和下降沿中断
void EXTI3_IRQHandler(void)
{

  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_3);

}
//spi3 dma方式接收 中断，这个必须用
void DMA2_Channel1_IRQHandler(void)
{
  HAL_DMA_IRQHandler(&hdma_spi3_rx);
}
// spi3 dma方式发送中断，这个用不到，但是必须有
void DMA2_Channel2_IRQHandler(void)
{
  HAL_DMA_IRQHandler(&hdma_spi3_tx);
}


