/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-13     liuwei       the first version
 */


#include "board.h"
#include "arm_math.h"

#include "check_sig.h"
#include "filter.h"
#include "sample_control.h"
#include "dev_param.h"

extern T_Device_Para global_devpa;
extern DMA_HandleTypeDef hdma_adc1;
extern q15_t dsp_buff[SAMPLING_POINTS];


q15_t fir_input[TEST_LENGTH_SAMPLES];
q15_t fir_output[TEST_LENGTH_SAMPLES];
q15_t fir_state[BLOCK_SIZE + NUM_TAPS - 1];
arm_fir_instance_q15 S_fir;
// 带通系数，该数组是对称的
q15_t fir_coe[128] =
{
        -97,    -60,    -18,     28,     73,    114,    148,    170,    180,
        175,    157,    124,     80,     28,    -29,    -86,   -138,   -182,
       -213,   -228,   -226,   -204,   -165,   -111,    -44,     29,    105,
        176,    237,    282,    307,    308,    284,    235,    164,     74,
        -30,   -138,   -244,   -339,   -413,   -460,   -473,   -448,   -383,
       -279,   -139,     30,    218,    414,    603,    772,    903,    980,
        988,    910,    729,    425,    -30,   -684,  -1641,  -3183,  -6359,
     -20724,  20724,   6359,   3183,   1641,    684,     30,   -425,   -729,
       -910,   -988,   -980,   -903,   -772,   -603,   -414,   -218,    -30,
        139,    279,    383,    448,    473,    460,    413,    339,    244,
        138,     30,    -74,   -164,   -235,   -284,   -308,   -307,   -282,
       -237,   -176,   -105,    -29,     44,    111,    165,    204,    226,
        228,    213,    182,    138,     86,     29,    -28,    -80,   -124,
       -157,   -175,   -180,   -170,   -148,   -114,    -73,    -28,     18,
         60,     97
}; //1mhz 45k hp

//带通滤波计算
void fir_u16_bp(uint16_t sig2_start_index)
{
    uint16_t i;;
    q15_t lift;
    //1、滤波
    lift = dsp_buff[sig2_start_index];    //获取抬升

  if(global_devpa.enable_filter)
  {
        //滤波
        for (i = 0; i < TEST_LENGTH_SAMPLES; ++i) {
            fir_input[i] = dsp_buff[(sig2_start_index + i)%SAMPLING_POINTS] - lift;
        }

        arm_fir_init_q15(&S_fir, NUM_TAPS, fir_coe,  fir_state, BLOCK_SIZE);
        for (i = 0; i < CNT_COMPUTE; ++i)
        {
            arm_fir_fast_q15(&S_fir, (fir_input+i*BLOCK_SIZE), (fir_output+i*BLOCK_SIZE), BLOCK_SIZE);

        }
  }else{

        //不滤波
        for (i = 0; i < TEST_LENGTH_SAMPLES; ++i) {
            fir_output[i] = dsp_buff[(sig2_start_index + i)%SAMPLING_POINTS] - lift;
        }
  }

}


/*对 滤波数据进行解码  32位
 * 用双数据窗 循环扫描
 * */
rt_bool_t Sig2_Decode(uint32_t *sig2code )
{
    uint16_t win1_index0, win1_indexn,  win2_indexn, first_top_index, integer_part, fractional_part;
    uint16_t code_index[32];
    uint8_t  code_index_cnt = 0, i, j;

    win1_index0 = 0;
    win1_indexn = win1_index0 + PEAK_WINDOW_INTERVAL;

    //一、查找第一位。  滤波后的数据波形图，，每一位 有两个波峰，查找每一位时要严格对比两个波峰 。
    while((win1_indexn+PEAK_WINDOW_LEN) < TEST_LENGTH_SAMPLES)
    {
        if (Win1_Check_Filtedata(win1_index0, win1_indexn))     //1、数据窗的方式检测到第一个 波
        {
            first_top_index = Find_MAX_index(win1_indexn);      //2、然后在win1_indexn附近找寻第一个波峰的顶点,


            win2_indexn = first_top_index + WIDTH_OF_1PEAK;     //3、顶点往后数73个点左右 ，数据窗二检测是否有第二个波峰，如果有，确定找到第一位，（可以顺便找一下第二个波峰的顶点）
            if ((win2_indexn + VAGUE_WIDTHPEAK)>= TEST_LENGTH_SAMPLES) {
                rt_kprintf("failed1\n");  //查找第一位失败。。
                return RT_FALSE;
            }
            if (Win2_Check_Filtedata(win2_indexn)) {
                code_index[code_index_cnt++] = first_top_index;    //4、保存第一位的顶点的标号
                goto FIND_NEXT_SIG2_BIT_CODE;
            }
        }

        win1_index0 += PEAK_WINDOW_STEP;
        win1_indexn = win1_index0 + PEAK_WINDOW_INTERVAL;
    }
    //二、 查找完首位后，以此为基准 解码剩下的 位 ，和查找第一位过程类似。。但是 为了代码清晰、调试方便 将查找第一位和剩余位分开。

FIND_NEXT_SIG2_BIT_CODE:
    win1_index0 =  first_top_index + DISTANCE_OF_2PEAK - VAGUE_DISTANCEPEAK;   //5、每位编码之间的距离大约是200， 跳转到下一位附近
    win1_indexn = win1_index0 + PEAK_WINDOW_INTERVAL;   //tail
    while((win1_indexn+PEAK_WINDOW_LEN) < TEST_LENGTH_SAMPLES)
    {
        if (Win1_Check_Filtedata(win1_index0, win1_indexn))      //查找第一个波峰
        {
            first_top_index = Find_MAX_index(win1_indexn);

            win2_indexn = first_top_index + WIDTH_OF_1PEAK;      //查找第二个波峰
            if ((win2_indexn + VAGUE_WIDTHPEAK)>= TEST_LENGTH_SAMPLES)
            {
                break; //查找结束
            }
            if (Win2_Check_Filtedata(win2_indexn)) {
                code_index[code_index_cnt++] = first_top_index;    //保存一位的顶点的标号
                goto FIND_NEXT_SIG2_BIT_CODE;  //下一位
            }

        }
        win1_index0 += PEAK_WINDOW_STEP;
        win1_indexn = win1_index0 + PEAK_WINDOW_INTERVAL;
    }


    rt_kprintf("cnt: %d: ", code_index_cnt);
    for (i = 0; i < code_index_cnt; ++i) {
        rt_kprintf("(%d,%d)", code_index[i], fir_output[code_index[i]]);
    }
    rt_kprintf("\n");
    if (code_index_cnt==0) {
        return RT_FALSE;
    }

    //三、 根据 各个位的序号 解编码
    rt_bool_t code[32] = {0};
    code[0] = 1;
    *sig2code = 0;
    *sig2code = 1; //最低位1

    for (i = 0, j=0; i < (code_index_cnt-1); ++i) //integer_part, fractional_part
    {
        integer_part    = (code_index[i+1] - code_index[i])   /200;
        fractional_part = (code_index[i+1] - code_index[i])   %200;
        if (fractional_part >=120) {
            integer_part ++;
        }
        j +=  integer_part;

        code[j] = 1;
        *sig2code |= 1<<(j);
    }
    for (i = 0; i < 32; ++i)
    {
        if (code[i]) {
            rt_kprintf("1");
        }
        else {
            rt_kprintf("0");
        }
    }
    rt_kprintf("\n");
    return RT_TRUE;
}


/*  decode find first peak
 * */
rt_bool_t Win1_Check_Filtedata(uint16_t a, uint16_t b)
{
    uint8_t i, cnt=0;
    for (i = 0; i < PEAK_WINDOW_LEN; ++i) {          //PEAK_WINDOW_THRESOLD
        if ( (fir_output[b+i] - fir_output[a+i] )>= PEAK_WINDOW_THRESOLD) {    //后者大于前者,没有取绝对值
            cnt ++;
        }
        if (cnt>=PEAK_THRESOLD_COUNT) {
            return RT_TRUE;
        }
    }
    return  RT_FALSE;
}
/* 查找最大值的 标号 波峰顶点
 * */
uint16_t Find_MAX_index(uint16_t a)
{
    uint16_t maxindex, i;
    maxindex = a;
    for (i = 1; i < PEAK_WINDOW_LEN+5; ++i) {
        if (fir_output[a + i] > fir_output[maxindex]) {
            maxindex = a+i;
        }
    }
    return maxindex;
}

/*第二个数据窗检测
 * */
rt_bool_t Win2_Check_Filtedata(uint16_t index)
{
    uint8_t cnt=0, i;

    for (i = 0; i < (VAGUE_WIDTHPEAK*2 +1) ; ++i) {    //中间加左右两边的                                     //PEAK2_WINDOW_THRESOLD
        if ((fir_output[index-VAGUE_WIDTHPEAK+i] - fir_output[index-PEAK2_WINDOW_INTERVAL-VAGUE_WIDTHPEAK+i])>=PEAK2_WINDOW_THRESOLD) {
            cnt ++;
        }
        if (cnt>=PEAK2_THRESOLD_COUNT) {
            return RT_TRUE;
        }
    }
    return RT_FALSE;
}

/************************************************/
//打印 fir 输入 输出
void Print_fir_output()
{
    uint16_t i;
    rt_kprintf("fir_input : \n");
    for (i = 0; i < TEST_LENGTH_SAMPLES; ++i) {
        rt_kprintf("%d ", fir_input[i]);
    }
    rt_kprintf("\n");
    rt_kprintf("fir_output : \n");
    for (i = 0; i < TEST_LENGTH_SAMPLES; ++i) {
        rt_kprintf("%d ", fir_output[i]);
    }
    rt_kprintf("\n");
}
/*****cmd****/

//打印
void pf()
{
    Print_fir_output();
    rt_kprintf("\nprint finish\n");
}
FINSH_FUNCTION_EXPORT(pf, print fir data);
MSH_CMD_EXPORT(pf, print fir data);

