/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-01-19     liuwei       the first version
 */

#include "board.h"
#include "rtthread.h"

#include "stdlib.h"

#include "RX8025T.h"
#include "universal_api.h"

extern I2C_HandleTypeDef hi2c1;


/*设置时间
 *
 * */
rt_bool_t Set_8025t(uint8_t *time)
{
    uint8_t buf[8];  //寄存器地址和数据共8个字节
    buf[0] = SEG_SEC;     //秒寄存器地址
    buf[1] = time[5]/10*16  + time[5]%10;     //秒
    buf[2] = time[4]/10*16  + time[4]%10;     //分钟
    buf[3] = time[3]/10*16  + time[3]%10;     //时

    buf[4] = 0x01;     //每天都是周日

    buf[5] = time[2]/10*16  + time[2]%10;     //日
    buf[6] = time[1]/10*16  + time[1]%10;     //月
    buf[7] = time[0]/10*16  + time[0]%10;      //年
/*
    uint8_t i;
    for (i = 0; i < 8; ++i) {
        rt_kprintf("0x%x ", buf[i]);
    }
    rt_kprintf("\n");
*/
    if(HAL_OK != HAL_I2C_Master_Transmit(&hi2c1, RX8025T_SLAVE_ADDR, buf, 8, 1000))
    {
        rt_kprintf("set8025t error");
        return RT_FALSE;
    }
    return RT_TRUE;
}


/*
 * 读取时间   参数是长度为8的数组，年 月 日  时 分 秒  ms
 * */
rt_bool_t Read_8025t(uint8_t *time)
{
    uint8_t buf[8];
    buf[0] = SEG_SEC;     //秒寄存器地址
    if(HAL_OK != HAL_I2C_Master_Transmit(&hi2c1, RX8025T_SLAVE_ADDR, buf, 1, 1000))
    {
        rt_kprintf("read8025t error1");
        return RT_FALSE;
    }
    if(HAL_OK != HAL_I2C_Master_Receive(&hi2c1, RX8025T_SLAVE_ADDR, &buf[1], 7, 1000))
    {
        rt_kprintf("read8025t error2");
        return RT_FALSE;
    }
    time[0] = (buf[7]&0xf0)/16 *10 + (buf[7]&0x0f);  //年
    time[1] = (buf[6]&0xf0)/16 *10 + (buf[6]&0x0f);  //月
    time[2] = (buf[5]&0xf0)/16 *10 + (buf[5]&0x0f);  //日

    time[3] = (buf[3]&0xf0)/16 *10 + (buf[3]&0x0f);  //时
    time[4] = (buf[2]&0xf0)/16 *10 + (buf[2]&0x0f);  //分
    time[5] = (buf[1]&0xf0)/16 *10 + (buf[1]&0x0f);  //秒

    time[6] = 0;  //毫秒
    time[7] = 0;
    return RT_TRUE;
}


/*增加一个查看8025t时间 和重新设置8025t时间的控制台 命令
 *  rx8025t 不加参数时打印 年月日时分秒
 *  有参数时  rx8025t 21 01 20 09 19 55
 * */
void rx8025t(int argc, char **argv)
{
    if (1== argc) {
        uint8_t buf[8];
        if(Read_8025t(buf)){
            Print_Uint8_Time(buf);
        }
    } else if(7 == argc){
        uint8_t buf[8];
        buf[0] = atoi(argv[1]);
        buf[1] = atoi(argv[2]);
        buf[2] = atoi(argv[3]);
        buf[3] = atoi(argv[4]);
        buf[4] = atoi(argv[5]);
        buf[5] = atoi(argv[6]);
        rt_kprintf("want to set: %d/%d/%d %d:%d:%d\n", buf[0],buf[1],buf[2],buf[3],buf[4],buf[5]);

        if (Set_8025t(buf)) {
            rt_kprintf("set success\n");
        }else {
            rt_kprintf("set failed\n");
        }

    }else{
        rt_kprintf("format error, rx8025t [year] [mon] [date] [hour] [min] [sec]\n");
    }

}
FINSH_FUNCTION_EXPORT(rx8025t, read or set 8025t);
MSH_CMD_EXPORT(rx8025t, read or set 8025t );

