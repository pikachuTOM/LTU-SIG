/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-20     liuwei       the first version
 */
#ifndef MY_CODE_CHECK_SIG_H_
#define MY_CODE_CHECK_SIG_H_

#endif /* MY_CODE_CHECK_SIG_H_ */

#if 0
//突变量检测配置相关
#define   DATA_WINDOW_INTERVAL    100   //数据窗间隔
#define   DATA_WINDOW_LEN         10    //数据窗长度
#define   DATA_WINDOW_STEP        10    //数据窗每次移动的 步长
#define   DATA_WINDOW_THRESOLD    300    //门槛值 ，差值
#define   THRESOLD_COUNT          3      //一个数据窗内 超过3个突变量就算 启动录波
#endif
//原始数据检测 突变量
#define   WIN_1_INTERVAL          50   //数据窗间隔
#define   WIN_1_LEN               3   //数据窗长度
#define   WIN_1_STEP              40   //数据窗每次移动的步长 step
#define   WIN_1_THRESOLD          80  //门槛值  165->120
#define   WIN_1_COUNT             2    //计数

#define   GET_SIG2_START_POINT(x)     ((x+ SAMPLING_POINTS - 200)%SAMPLING_POINTS)  //多向前200个点       //由当前录波起始位置 获取 实际对时信号起始位置，起码 要包含第一个对时波峰
#define   SIG2_MORE_BUF_POINT     200     //在6400的基础上 多缓冲600个点


void Check_Sig_Thread();

int16_t Get_DMA_Index();
rt_bool_t Check_Threshold(uint16_t index_0, uint16_t index_n);
q15_t Diff_q15(q15_t a, q15_t b);


rt_bool_t Check_Win1(uint16_t index_0, uint16_t index_n);
rt_bool_t Check_Win2(uint16_t index_0, uint16_t index_n);
rt_bool_t Check_FirstHalf(uint16_t *p_win1_index0);
rt_bool_t Check_SecondHalf(uint16_t *p_win1_index0);

rt_bool_t Check_Bit2(uint16_t  win1_index0);

