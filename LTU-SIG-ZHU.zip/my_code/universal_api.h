/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-04     liuwei       the first version
 */
#ifndef MY_CODE_UNIVERSAL_API_H_
#define MY_CODE_UNIVERSAL_API_H_



#endif /* MY_CODE_UNIVERSAL_API_H_ */



void Uint8_Correct_Time(uint8_t *data);
void PrintFloat(float value);
