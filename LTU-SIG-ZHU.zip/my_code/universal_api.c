/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-04     liuwei       the first version
 */

#include "board.h"
#include "universal_api.h"

extern RTC_HandleTypeDef hrtc;

//将 八字节时间数组，写入系统rtc

void Uint8_Correct_Time(uint8_t *data)
{
    RTC_DateTypeDef sDate = {0};  //结构体种还有很多其他变量需要赋值，所以 {0} 不要去掉
    RTC_TimeTypeDef sTime = {0};

    sDate.Year = data[0];
    sDate.Month = data[1];
    sDate.Date = data[2];

    sTime.Hours = data[3];
    sTime.Minutes = data[4];
    sTime.Seconds = data[5]+1;
    //sTime.SubSeconds = data[6] * 256 + data[7];
    //uint8_t i;
    //for (i = 0; i < 8; ++i) {
        //rt_kprintf("%d ", data[i]);
    //}

    HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
    HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
}
/*
   获取时间并转换成数组格式 例如    //20年3月31日，10:58:30 0ms
                                          共8字节，例如  20 03 31，  10 58 30， 00
 * */
void Get_Time_8(uint8_t * data)
{
    RTC_DateTypeDef sDate;
    RTC_TimeTypeDef sTime;
    HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
    HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
    data[0] = sDate.Year;
    data[1] = sDate.Month;
    data[2] = sDate.Date;

    data[3] = sTime.Hours;
    data[4] = sTime.Minutes;
    data[5] = sTime.Seconds;

    sTime.SubSeconds = (uint32_t)(sTime.SubSeconds*1000/1024+0.5);
    data[6] = sTime.SubSeconds / 256;    //整 256的整数倍
    data[7] = sTime.SubSeconds % 256;    //余
}

void Print_Uint8_Time(uint8_t *data)
{
    rt_kprintf("20%d/%d/%d-%d:%d:%d:%d\n", \
            data[0], data[1],data[2],data[3],data[4],data[5],data[6]*256+data[7]);

}

//打印 float整数与小数， 保留三位小数
void PrintFloat(float value)
{
    rt_bool_t symbol;
    int tmp0, tmp1, tmp2, tmp3;
    if (value >=0) {
        symbol = RT_TRUE;
    }else {
        symbol = RT_FALSE;
        value = 0- value;
    }

    tmp0 = (int)value;
    tmp1 = ( (int)((value -tmp0)*10) )%10;
    tmp2 = ( (int)((value -tmp0)*100) )%10;
    tmp3 = ( (int)((value -tmp0)*1000) )%10;

    if (symbol) {
        rt_kprintf(" %d.%d%d%d ",tmp0,tmp1,tmp2,tmp3);
    }else {
        rt_kprintf("-%d.%d%d%d ",tmp0,tmp1,tmp2,tmp3);
    }
}
