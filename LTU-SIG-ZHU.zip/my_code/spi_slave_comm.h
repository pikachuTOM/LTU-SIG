/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-05     liuwei       the first version
 */
#ifndef MY_CODE_SPI_SLAVE_COMM_H_
#define MY_CODE_SPI_SLAVE_COMM_H_
#endif /* MY_CODE_SPI_SLAVE_COMM_H_ */

#define   SPI3_REV_BUF_LEN     32
#define   SPI3_TX_BUF_LEN      32

#define   spi3_RX_EVENT_FLAG   (1<<1)


//长度 定义
#define    DATA_FRAME_LENGTH    32                   //接收和发送数据帧长度一样

#define    TX_BUF_LEN    (DATA_FRAME_LENGTH + 10)    //传输 buf的长度
#define    RX_BUF_LEN    (DATA_FRAME_LENGTH + 10)    //接收 buf的长度

#define    TX_DATA_LEN   (DATA_FRAME_LENGTH + 0)     //每次传输数据的长度，增加2是为了触发 dma完成中断。
#define    RX_DATA_LEN   (DATA_FRAME_LENGTH + 0)     //每次接收数据的长度
//数据帧索引号
#define    INDEX_HEAD    0    //包头
#define    INDEX_COMM    1    //命令字
#define    INDEX_CTL     2    //控制字
#define    INDEX_LEN     3    //长度
#define    INDEX_DATA    4    //数据
#define    INDEX_Frame_Check   (DATA_FRAME_LENGTH - 2)     //校验
#define    INDEX_STOP          (DATA_FRAME_LENGTH - 1)    //停止
#define    MAX_DATA_SIZE       (DATA_FRAME_LENGTH - 6)     //最大数据长度 32-6=26
//包头包尾 固定字
#define    MESSAGE_HEAD           0x68     //包头
#define    MESSAGE_TAIL           0x69     //包尾
//主机给从从机的 命令字
#define    SLAVE_REBOOT                0x01          //从机重启
#define    SLAVE_Topological_Signal    0x02              //控制从机发送一次拓扑信号
#define    SLAVE_Time_Signal           0x03              // 控制从机对时信号，从数据里看 是开启还是关闭
#define    SLAVE_UPDATE                0X04          //升级命令
#define    SLAVE_READ_APP_PARAM        0x05              //主机读取从机的apppara
#define    SLAVE_READ_TOPO             0x06          //主机读取从机拓扑数据
#define    SLAVE_CORRECT_TIME          0x07          //从机校正时间
#define    SLAVE_CFFT_THRESOLD         0x08          //主机设置从机的 门槛值
#define    READ_SLAVE_TIME             0x09          //主机获取从机的时间

//控制字
#define    SLAVE_READY_UPGRADE   0x01   //从机准备升级
#define    UPGRADE_DATA          0X02   //升级的数据

// sig板 升级文件 on chip
#define    SUB_SIZE_CHIPFLASH     2048 //片内flash 子扇区大小
#define    UPGRADE_DATA_SUBNUM    70   //升级程序起始扇区号,其实是从70的尾部开始
#define    UPGRADE_APP_PARA_ADDR   (71*2048 -256)


typedef struct msg_spi_comm12323{
    uint8_t data;
    uint8_t a[9];  //无效的填充
}T_msg_spi;

void Spi_Slave_Recieve_Thread();
void IPC_spi_comm_init();
void Start_Spi3_DMA_Receive();
void Start_Spi3_DMA_Trans(uint8_t *tx_data, uint16_t size);
void Create_Head_Tail(void);
rt_bool_t Create_Comm_Len_Data(uint8_t comm, uint8_t *data, uint8_t data_size);

uint8_t Create_Check_Code(uint8_t *data, uint8_t size);
uint8_t Message_Analysis();
rt_bool_t Slave_Update_Process();
rt_bool_t Read_RunApp_Param_Process();
rt_bool_t Read_Topo_Proccess();
rt_bool_t Slave_Correct_Time_Proccess();
rt_bool_t Slave_Set_Cfft_Proccess();

rt_bool_t Slave_Time_Proccess();
rt_bool_t Slave_Read_Time_Proccess();

typedef struct
{
    uint8_t Psw[6];
    uint8_t D_ID[6];
    char MB_SV[8];
    char MB_HV[8];
    char SG_SV[8];
    char SG_HV[8];
    char D_Name[32];
    uint8_t GW_ID[6];

}offchip_param;







