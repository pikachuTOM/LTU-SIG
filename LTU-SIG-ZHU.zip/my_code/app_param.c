/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-22     liuwei       the first version
 */
#include "board.h"

#include "app_param.h"
#include "chipflash.h"


//获取 app参数

void Get_APP_Param(App_Param * data, uint32_t addr)
{
    App_Param *p;
    p = (App_Param *)(addr);
    rt_memcpy(data, p, sizeof(App_Param));
}

//打印app参数
void Print_APP_Param(uint32_t addr)
{
    uint8_t i;
    App_Param *p = (App_Param *)(addr);
    rt_kprintf("*app_file_size: %d\n*", p->app_file_size);

    for (i = 0; i < 8; ++i) {
        rt_kprintf("%c",p->SV[i]);
    }
    rt_kprintf("\n*");
    for (i = 0; i < 8; ++i) {
        rt_kprintf("%c",p->HV[i]);
    }
    rt_kprintf("\n*soft type:");
    for (i = 0; i < 2; ++i) {
        rt_kprintf("%c",p->type[i]);
    }
    rt_kprintf("\n");
}

//删除 runninig app
void Erase_Running_App_Data()
{
    App_Param *p = (App_Param *)(RUN_APP_PARAM);
    if(HAL_OK != HAL_FLASH_Unlock()){
            rt_kprintf("Fla Unlo\n");
    }
    //擦除
    if(0!= My_Flash_Erase(RUN_APP_PARAM_SUBNUM, p->app_file_size /2048 +1) ){
            rt_kprintf("DevParErase\n");
    }

    HAL_FLASH_Lock();

}


//控制台，打印app 参数
void app_param(void)
{
    rt_kprintf("*running app param:\n");
    Print_APP_Param(RUN_APP_PARAM);
    rt_kprintf("\n*backup app param:\n");
    Print_APP_Param(BACK_APP_PARAM);
}
FINSH_FUNCTION_EXPORT(app_param, print app param);
MSH_CMD_EXPORT(app_param, print app param);

//控制台，打印app 参数
void erase_run_app_data(void)
{
    Erase_Running_App_Data();
}
FINSH_FUNCTION_EXPORT(erase_run_app_data, erase run app data);
MSH_CMD_EXPORT(erase_run_app_data, erase run app data);




