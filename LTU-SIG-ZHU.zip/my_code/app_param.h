/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-06-22     liuwei       the first version
 */

#define  RUN_APP_PARAM      0x08004700            //当前正在运行的 app参数信息
#define  BACK_APP_PARAM     (71*2048 -256)        //备份区的app参数信息

#define  RUN_APP_PARAM_SUBNUM    8      //app参数所在的 扇区号

typedef struct
{
    uint32_t head_sign;
    uint32_t app_check_size;
    uint32_t app_param_size;
    uint32_t app_file_size;          //文件总大小
    char         SV[8];              //软件版本
    char         HV[8];              //硬件版本
    char         type[2];            //升级软件类型
    uint8_t  creat_time[6];
    uint32_t App_CRC;
    uint32_t end_sign;
    int      erro;
}App_Param;
