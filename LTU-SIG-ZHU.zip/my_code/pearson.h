/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-20     liuwei       the first version
 */
#ifndef MY_CODE_PEARSON_H_
#define MY_CODE_PEARSON_H_



#endif /* MY_CODE_PEARSON_H_ */


void Code_Analysis();
