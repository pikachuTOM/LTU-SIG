/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-01-19     liuwei       the first version
 */
#ifndef MY_CODE_RX8025T_H_
#define MY_CODE_RX8025T_H_



#define RX8025T_SLAVE_ADDR    (0x64)  //RX8025T从机地址
// 8025t 内部寄存器地址
enum
{
    SEG_SEC = 0,
    SEG_MIN,
    SEG_HOUR,
    SEG_WEEK,
    SEG_DAY,
    SEG_MONTH,
    SEG_YEAR,
};

rt_bool_t Set_8025t(uint8_t *time);
rt_bool_t Read_8025t(uint8_t *time);

#endif /* MY_CODE_RX8025T_H_ */
