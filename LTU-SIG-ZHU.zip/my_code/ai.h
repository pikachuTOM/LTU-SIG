/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */
#ifndef MY_CODE_AI_H_
#define MY_CODE_AI_H_
#endif /* MY_CODE_AI_H_ */

//soe
#define   SOE_BUF_LEN  10       //soe消息队列长度
#define   SIZE_PER_SOE_MQ  19   //8字节时间 + 2*5字节数据 + 数据类型最后一位是数据类型 （0x01 拓扑soe)(0x02 对对时数据)

// dma传输半中断和完全中断 用于通知 突变量检测程序
#define   HALF_DMA_EVE_FLAG     (1<<30)   //DMA缓冲完一半
#define   CPLT_DMA_EVE_FLAG     (1<<31)   //dma缓冲完全部


////
void Print_adc_buff(void);
void Cfft_Thread(void);
void Pick32out5000(uint8_t half);
void IPC_ai_Init(void);



void Print_10000(void);
void Print_512(void);
uint8_t index_2_(uint16_t x);
void Get_Time_8(uint8_t * data);
void topo_stop(uint8_t index);


