/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */
#ifndef MY_CODE_INIT_H_
#define MY_CODE_INIT_H_



#endif /* MY_CODE_INIT_H_ */

#define THREAD1_STACK_SIZE  256   //led
#define THREAD2_STACK_SIZE  1024   //cfft
#define THREAD3_STACK_SIZE  512    //sig
#define THREAD4_STACK_SIZE  512    //spi2 com
#define THREAD5_STACK_SIZE  1024   //check sig2

void init();
void thread1_entry(void *para);
void thread2_entry(void *para);
void thread3_entry(void *para);
void thread4_entry(void *para);
void thread5_entry(void *para);

void Set_TIM7(uint32_t Prescaler, uint32_t count);

extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern RTC_HandleTypeDef hrtc;
extern TIM_HandleTypeDef htim6;
