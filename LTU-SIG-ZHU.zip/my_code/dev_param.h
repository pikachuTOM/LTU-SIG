/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-04     liuwei       the first version
 */
#ifndef MY_CODE_DEV_PARAM_H_
#define MY_CODE_DEV_PARAM_H_


#define  DEV_PARAM_SUBNUM    120   //设备参数片内扇区号

typedef struct{
    //rt_uint8_t is_new;   //是否有效标志
    int16_t cff_threshold[2];   //拓扑识别 判据 门槛值  , 387.8 和487.5用第1个， 287.8 和387.5用第2个

    uint16_t win1_threshold[3];        //对时信号突变量检测门槛值//解码时第一个波峰门槛值//解码时第二个波峰门槛值
    rt_bool_t enable_filter;           //是否使能滤波


    uint16_t sig_send_frec;    //发送频率为



    rt_uint8_t is_new;   //是否有效标志

    //uint8_t a[3];   //填充 请勿删除

}T_Device_Para;


void Dev_Param_Init();
void Print_Devpa();
void Save_Dev_Para();













#endif /* MY_CODE_DEV_PARAM_H_ */
