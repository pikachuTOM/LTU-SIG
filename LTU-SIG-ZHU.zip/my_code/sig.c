/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-19     liuwei       the first version
 */
#include "board.h"
#include "string.h"
#include "arm_math.h"

#include "sig.h"
#include "universal_api.h"
#include "filter.h"
#include "sample_control.h"

extern void MX_ADC1_Init(void);

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim6;
extern DMA_HandleTypeDef hdma_adc1;
extern TIM_HandleTypeDef htim7;

extern rt_bool_t enable_topo_recv;
extern rt_bool_t enable_time_recv;
extern uint16_t i_num;
extern q15_t dsp_buff[SAMPLING_POINTS];


rt_bool_t enable_time_send = RT_FALSE;
rt_bool_t enable_topo_send = RT_TRUE;
rt_bool_t en_cyc_send = RT_FALSE;

uint16_t sig_send_frc_cnt[3];    //拓扑信号发送频率
/**********************拓扑信号******************************/
void Set_TIM7(uint32_t Prescaler, uint32_t count);

//设置 tim7的参数
void Set_Start_SIG(rt_uint16_t  Prescaler, rt_uint16_t cnt)
{
    Set_TIM7(Prescaler, cnt);         //设置 tim7
    HAL_TIM_Base_Start_IT(&htim7);    //启动tim7
    //rt_thread_mdelay(80);             //让其运行 80ms，在其中断中反转电平
    rt_thread_mdelay(100);
    HAL_TIM_Base_Stop_IT(&htim7);     //停止tim7

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);     //电平置1 安全
    rt_thread_mdelay(100);
}
//发出信号  发送拓扑信号
void Sig()
{
    if (enable_topo_send) {
        //Set_Start_SIG(8-1, 21053);      //237.5HZ


        //Set_Start_SIG(4-1, 29630);     //337.5HZ
        //Set_Start_SIG(4-1, 22857);     //437.5HZ
#if 1
        //Set_Start_SIG(4-1, 28571);   //350hz
        //Set_Start_SIG(4-1, 22222);   //450hz

        //Set_Start_SIG(4-1, 18605);   //537.5hz
        //Set_Start_SIG(4-1, 15686);   //637.5hz
        //Set_Start_SIG(4-1, 13559);   //737.5hz
        //Set_Start_SIG(4-1, 11940);   //837.5hz
        //Set_Start_SIG(4-1, 10667);   //937.5hz

        Set_Start_SIG(4-1, sig_send_frc_cnt[0]);     // 变频
        rt_thread_mdelay(1000);
        Set_Start_SIG(4-1, sig_send_frc_cnt[1]);
        rt_thread_mdelay(1000);  //强制休息 1s
        Set_Start_SIG(4-1, sig_send_frc_cnt[2]);
        rt_thread_mdelay(1000);  //强制休息 1s
#endif
        rt_kprintf("sig end\r\n");
    }
}
/*****************************************************************/

/***********************对时信号*******************************/

//对时信号编码
rt_bool_t sig2_enable = RT_FALSE;//RT_TRUE;////
struct rt_event sig2_event;
rt_bool_t is_pg = RT_FALSE;    //测试打印

                             //增加前导码1110
rt_bool_t sig2_code[32] = {1,1,1,0, 1,0,0,1,1,0,1,1,1,  0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1 };//{1,0,0,1,1,0,1,1,1,  0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1};   //默认100110111....
uint8_t sig2_len = 32;

//GPIO 中断回调  上升沿和下降沿都会中断
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (is_pg) {
        rt_kprintf("g");
    }

    if(enable_time_send && sig2_enable  ){
        //send
        rt_event_send(&sig2_event, EVE_FLAG_PEACK_SIG2);
        sig2_enable = RT_FALSE;    //收到一次脉冲后，关闭防止再次发送事件
    }
}

/*高电平周期  ,每个周期200us
 * */
void high_period(void)
{
    rt_hw_us_delay(200);
}
/*低电平周期
 * */
void low_period(void)
{
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);  //低
    rt_hw_us_delay(10);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
    rt_hw_us_delay(190);
}


// 对时信号发送函数，等待 来了脉冲，中断后 接收事件即可在波峰处发送一个信号
void Thread_Sig2(void)
{
   uint8_t i;
   uint32_t e;
    while(1){
        if(RT_EOK ==  rt_event_recv(&sig2_event, EVE_FLAG_PEACK_SIG2, RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, RT_WAITING_FOREVER, &e))
        {
            for (i = 0; i < sig2_len; ++i)
            {
                if(sig2_code[i])
                {
                    low_period();
                } else {
                    high_period();
                }
            }
            rt_kprintf("sig 2 end\r\n");
            rt_thread_mdelay(1500);   //每一秒钟发送一次对时信号

            if (en_cyc_send) {
                rt_thread_mdelay(7500);
                sig2_enable = RT_TRUE;    //重新使能可以再次发送}
            }

        }
    }
}

void IPC_Sig2_Init(void)
{
    if(RT_EOK != rt_event_init(&sig2_event, "sig2eve", RT_IPC_FLAG_FIFO)){
         rt_kprintf("sig2EveErr\r\n");
    }

}




/***********************************/
/*开启 拓扑关闭对时
 *
 * */
void Enable_Topo(void)
{

    //关闭 tim和定时器
    HAL_TIM_Base_Stop_IT(&htim6);
    HAL_ADC_Stop_DMA(&hadc1);

    //1、先关闭对时
    enable_time_send= RT_FALSE;  //关闭对时 发送
    enable_time_recv = RT_FALSE;  //关闭对时接收
    //rt_thread_mdelay(1000);
    //2、开启拓扑
    i_num = 0;
    enable_topo_recv = RT_TRUE ;  //开启拓扑接收
    enable_topo_send = RT_TRUE;   //开启拓扑发送

    //switch adc channel
    MX_ADC1_Init();
    //重启dma和定时器
    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dsp_buff, SAMPLING_POINTS);
    HAL_TIM_Base_Start_IT(&htim6);

    rt_kprintf("time->topo\n");
}

/*开启对时  关闭拓扑
 *
 * */
void Enable_Time(void)
{
    //关闭tim和dma
    HAL_TIM_Base_Stop_IT(&htim6);
    HAL_ADC_Stop_DMA(&hadc1);
    //1、关闭拓扑
    enable_topo_recv = RT_FALSE ;
    enable_topo_send = RT_FALSE;
    //2、开启对时
    enable_time_recv = RT_TRUE;
    //sig2_enable = RT_TRUE;
    enable_time_send= RT_TRUE;     //需要 重新设置下 dma等

    //switch adc channel
    MX_ADC1_Init();
    //重启dma和定时器
    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dsp_buff, SAMPLING_POINTS);
    HAL_TIM_Base_Start_IT(&htim6);
    rt_kprintf("topo->time\n");
}
/*********************************************************************/
//手动修改编码   md
long msd(int argc, char **argv)
{
    if (2 == argc) {
        if (strlen(argv[1]) <sig2_len) {
            rt_kprintf("code len need >%d\n",sig2_len);
        }else {
            uint8_t i;
            rt_kprintf("new code:");
            for (i = 0; i < sig2_len; ++i) {
                if ('1' == argv[1][i]) {
                    sig2_code[i] =  1;
                    rt_kprintf("1");
                }else {
                    sig2_code[i] = 0;
                    rt_kprintf("0");
                }
            }
            rt_kprintf("\n");
        }
    }else{
        rt_kprintf("msd [code], ep: msd 100110111...\n");
    }
    return 0;
}
FINSH_FUNCTION_EXPORT(msd, modify sig2 code);
MSH_CMD_EXPORT(msd, modify sig2 code);
// 对时功能和拓扑功能切换
long sttf()
{
    if (enable_time_recv) {
        Enable_Topo();
    }else{
        Enable_Time();
    }
    return 0;
}
FINSH_FUNCTION_EXPORT(sttf, Switch time  and topology functions);
MSH_CMD_EXPORT(sttf,  Switch time  and topology functions);


//开始 对时数据发送
void sig2()
{
    sig2_enable = RT_TRUE;
}
FINSH_FUNCTION_EXPORT(sig2, tx time signal);
MSH_CMD_EXPORT(sig2,  tx time signal);

//使能循环发送 en_cyc_send
void ecs()
{
    if (en_cyc_send) {
        en_cyc_send = RT_FALSE;
        rt_kprintf("disen cyc send\n");
    }else {
        en_cyc_send = RT_TRUE;
        rt_kprintf("enable cyc send\n");
    }

}
FINSH_FUNCTION_EXPORT(ecs, enable Circular transmission);
MSH_CMD_EXPORT(ecs,  Cyclic Circular transmission);

