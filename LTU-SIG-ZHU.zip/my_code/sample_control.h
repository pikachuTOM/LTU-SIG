/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-17     liuwei       the first version
 */
#ifndef MY_CODE_SAMPLE_CONTROL_H_
#define MY_CODE_SAMPLE_CONTROL_H_

#endif /* MY_CODE_SAMPLE_CONTROL_H_ */


#define   SAMPLING_FREQUENCY     1000       //KhZ
#define   SAMPLING_POINTS        10000      //1mhz采样 10ms 1w个点
#define   SIG_CODE_LEN           (200*32)    //1 mhz情况下 每位是200个数据点，共32位

#define   SIG2_CODE_NUM          (32)        //32位编码
