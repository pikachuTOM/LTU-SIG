/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-04     liuwei       the first version
 */


#include "board.h"

#include "stdio.h"
#include "string.h"
#include "stdlib.h"

#include "dev_param.h"
#include "chipflash.h"


extern uint16_t sig_send_frc_cnt[3];
extern uint16_t cfft_check_point[4];


T_Device_Para global_devpa;   //全局设备参数

/*
 * 设备参数初始化
 * */
#define DEVPA_IS_NEW  (0x06)    //20210114修改为0x04,给理工大升级并测试了。 拓扑幅值 65-》60 60不报
                                //20210115修改为0x05,给理工大升级并测试了。  拓扑幅值60——》50
                                //2021 01 16 测试方案三， 突变量差值门槛值改为  30 30
                                //2021 01 18方案三，修改设备参数为 0x06

void Dev_Param_Init()
{
    T_Device_Para *p;
    p = (T_Device_Para *)(DEV_PARAM_SUBNUM * 2048);
    rt_memcpy(&global_devpa, p, sizeof(T_Device_Para));

    if (global_devpa.is_new != DEVPA_IS_NEW) {  //使用默认参数
        rt_kprintf("use default device parament:\r\n");
        global_devpa.is_new = DEVPA_IS_NEW;
        global_devpa.cff_threshold[0] = 30;//50;   //
        global_devpa.cff_threshold[1] = 30;//50;
        global_devpa.win1_threshold[0] = 80;
        global_devpa.win1_threshold[1] = 50;
        global_devpa.win1_threshold[2] = 5;
        global_devpa.enable_filter = RT_FALSE;
        global_devpa.sig_send_frec = 3625;   // 362.5Hz
        //保存
        if(HAL_OK != HAL_FLASH_Unlock()){
                rt_kprintf("Fla Unlo\n");
        }
        //擦除
        if(0!= My_Flash_Erase(DEV_PARAM_SUBNUM, 1) ){
                rt_kprintf("DevParErase\n");
        }
        //写入
        if(My_Flash_Program(DEV_PARAM_SUBNUM * 2048, &global_devpa, sizeof(global_devpa)))
        {
            rt_kprintf("program devpara error\n");
        }
        HAL_FLASH_Lock();



    }else {
        rt_kprintf("flash device parament:\r\n");
    }

    //打印
    Print_Devpa();
    //生效
    sig_send_frc_cnt[0] = (uint16_t)(20*1000*1000*10 /1.0 / global_devpa.sig_send_frec /2 +0.5) ;    //设置 拓扑信号发送频率
    sig_send_frc_cnt[1] = (uint16_t)(20*1000*1000*10 /1.0 / (global_devpa.sig_send_frec+1000) /2 +0.5) ;
    sig_send_frc_cnt[2] = (uint16_t)(20*1000*1000*10 /1.0 / (global_devpa.sig_send_frec+2000) /2 +0.5) ;
    rt_kprintf("sig end frec cnt:%d %d %d\n", sig_send_frc_cnt[0], sig_send_frc_cnt[1],sig_send_frc_cnt[2]);

    cfft_check_point[0] = (global_devpa.sig_send_frec-500) /125;    //设置要检测的频点
    cfft_check_point[1] = (global_devpa.sig_send_frec+500) /125;
    cfft_check_point[2] = (global_devpa.sig_send_frec+1500) /125;
    cfft_check_point[3] = (global_devpa.sig_send_frec+2500) /125;

    rt_kprintf("cfft check point: %d %d %d %d\n", cfft_check_point[0], cfft_check_point[1], cfft_check_point[2], cfft_check_point[3]);
}

/*打印设备参数
*/
void Print_Devpa()
{
    rt_kprintf("\n*LTU-SIG dev para: 0x%x\n",global_devpa.is_new);
    rt_kprintf("*cfft threshold: (?):%d, (?):%d\n", global_devpa.cff_threshold[0], global_devpa.cff_threshold[1]);
    rt_kprintf("*win1_threshold: %d\n", global_devpa.win1_threshold[0]);
    rt_kprintf("*decode1_threshold: %d, decode1_threshold: %d\n", global_devpa.win1_threshold[1], global_devpa.win1_threshold[2]);
    if (global_devpa.enable_filter) {
        rt_kprintf("*enable filter\n");
    } else {
        rt_kprintf("*disenable filter\n");
    }
    rt_kprintf("*sig2 frec:%dHz\n",global_devpa.sig_send_frec);
}


void Save_Dev_Para()
{
    //保存
    if(HAL_OK != HAL_FLASH_Unlock()){
            rt_kprintf("Fla Unlo\n");
    }
    //擦除
    if(0!= My_Flash_Erase(DEV_PARAM_SUBNUM, 1) ){
            rt_kprintf("DevParErase\n");
    }
    //写入
    if(My_Flash_Program(DEV_PARAM_SUBNUM * 2048, &global_devpa, sizeof(global_devpa)))
    {
        rt_kprintf("program devpara error\n");
    }
    HAL_FLASH_Lock();
    rt_kprintf("need reboot\n");
}

/********************************************/
/* 控制台修改 设备参数
 * */
long rdp(int argc, char **argv)
{

    //保存
    if(HAL_OK != HAL_FLASH_Unlock()){
            rt_kprintf("Fla Unlo\n");
    }
    //擦除
    if(0!= My_Flash_Erase(DEV_PARAM_SUBNUM, 1) ){
            rt_kprintf("DevParErase\n");
    }
    HAL_FLASH_Lock();
    rt_kprintf("need reboot\n");
    return 0;
}
FINSH_FUNCTION_EXPORT(rdp, reset device Default parament);
MSH_CMD_EXPORT(rdp, creset device Default parament);
/* 打印设备参数
 * */
long devpa(int argc, char **argv)
{
    Print_Devpa();
    return 0;
}
FINSH_FUNCTION_EXPORT(devpa, print device  parament);
MSH_CMD_EXPORT(devpa, print device  parament);
/* 控制台修改 设备参数
 * */
long cct(int argc, char **argv)
{

    if (3 != argc) {
        rt_kprintf("Format error");
        return 0;
    }
    global_devpa.cff_threshold[0] = (int16_t)atoi(argv[1]);
    global_devpa.cff_threshold[1] = (int16_t)atoi(argv[2]);

    rt_kprintf("NEW cfft threshold: (378.5,487.5):%d, (437.5):%d\n\n", global_devpa.cff_threshold[0], global_devpa.cff_threshold[1]);
    rt_kprintf("need save ,reboot\n");
    return 0;
}
FINSH_FUNCTION_EXPORT(cct, change cfft threshold);
MSH_CMD_EXPORT(cct, change cfft threshold);

long save(int argc, char **argv)
{

    //保存
    if(HAL_OK != HAL_FLASH_Unlock()){
            rt_kprintf("Fla Unlo\n");
    }
    //擦除
    if(0!= My_Flash_Erase(DEV_PARAM_SUBNUM, 1) ){
            rt_kprintf("DevParErase\n");
    }
    //写入
    if(My_Flash_Program(DEV_PARAM_SUBNUM * 2048, &global_devpa, sizeof(global_devpa)))
    {
        rt_kprintf("program devpara error\n");
    }
    HAL_FLASH_Lock();
    rt_kprintf("need reboot\n");
    return 0;
}
FINSH_FUNCTION_EXPORT(save, save device parament);
MSH_CMD_EXPORT(save, save device parament);

long ctp(int argc, char **argv)
{

    if (argc == 3) {
        uint8_t index = atoi(argv[1]);
        uint16_t value = atoi(argv[2]);
        rt_kprintf("%d %d\n", index, value);
        if (index < 3) {
            global_devpa.win1_threshold[index] = value;
        } else {
            rt_kprintf("para2 within 0~2\n");
        }

    } else {
        rt_kprintf("format error: ctp [0~2] [value]\n");
    }


    return 0;
}
FINSH_FUNCTION_EXPORT(ctp, change time parament);
MSH_CMD_EXPORT(ctp, change time parament);


long ef(int argc, char **argv)
{

    if (global_devpa.enable_filter) {
        global_devpa.enable_filter = RT_FALSE;
        rt_kprintf("disenable filter\n");

    } else {
        global_devpa.enable_filter = RT_TRUE;
        rt_kprintf("enable filter\n");
    }


    return 0;
}
FINSH_FUNCTION_EXPORT(ef, enable filter);
MSH_CMD_EXPORT(ef, enable filter);

/*修改 拓扑信号发送和检测频率
 * */

long ctf(int argc, char **argv)
{

    if (2==argc) {
        global_devpa.sig_send_frec = (uint16_t)atoi(argv[1]);
        rt_kprintf("*sig2 frec:%d\n",global_devpa.sig_send_frec);
    } else {
        rt_kprintf("format error, ep: ctf 4375, change topo frec =437.5hz\n");
    }

    return 0;
}
FINSH_FUNCTION_EXPORT(ctf, change topo frec);
MSH_CMD_EXPORT(ctf, change topo frec);




