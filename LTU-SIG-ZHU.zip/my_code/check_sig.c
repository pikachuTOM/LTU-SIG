/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-18     liuwei       the first version
 */


//使用  检测突变量的方法 检测对时信号，启动录波


#include "board.h"
#include "arm_math.h"

#include "sample_control.h"
#include "check_sig.h"
#include "pearson.h"
#include "filter.h"
#include "ai.h"
#include "dev_param.h"

extern q15_t dsp_buff[SAMPLING_POINTS];
extern struct rt_event cfft_event;
extern struct rt_messagequeue mq_topo;
extern T_Device_Para global_devpa;

extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern TIM_HandleTypeDef htim6;

uint16_t win_1_thresold;
rt_bool_t stop_enable = RT_FALSE;


/*突变量检测对时信号 启动录波，之后再滤波, 再pearson分析解除编码
 *
 */
void Check_Sig_Thread()
{
    rt_uint32_t e, code;
    uint16_t win1_index0, sig2_start_point, sig2_end_point, dma_index;
    uint8_t soe_buf[SIZE_PER_SOE_MQ];

    win_1_thresold = global_devpa.win1_threshold[0];//初始化 门槛值

    goto  IS_JUST_POWER;
RESTART_CHECK:
    rt_event_recv(&cfft_event, (HALF_DMA_EVE_FLAG|CPLT_DMA_EVE_FLAG), RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, 0, &e);  //必须清除一下接收事件

    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dsp_buff, SAMPLING_POINTS);
    HAL_TIM_Base_Start_IT(&htim6);

IS_JUST_POWER:
    win1_index0 = 0;
    //1、检测 原始波形的 突变量启动录波
    while(1)
    {
        if(RT_EOK ==  rt_event_recv(&cfft_event, (HALF_DMA_EVE_FLAG|CPLT_DMA_EVE_FLAG), RT_EVENT_FLAG_OR|RT_EVENT_FLAG_CLEAR, -1, &e))
        {
            if (HALF_DMA_EVE_FLAG==e)
            {
                    if (Check_FirstHalf(&win1_index0)) //检测前 半个缓冲
                    {
                        goto HAVE_SIG2;
                    }

            }else if(CPLT_DMA_EVE_FLAG==e)
            {
                    if (Check_SecondHalf(&win1_index0)) //检测后 半个缓冲
                    {
                        goto HAVE_SIG2;
                    }
            }else
            {
                rt_kprintf("E\n");
            }
        }else
        {
            rt_kprintf("check sig2 timeout\n");
        }

    }//end while

        //2、检测到突变量后， 等待缓冲
HAVE_SIG2:

        sig2_start_point = GET_SIG2_START_POINT(win1_index0);                //计算sig2 起始点和结束点
        sig2_end_point =  (sig2_start_point + SIG_CODE_LEN + SIG2_MORE_BUF_POINT)%SAMPLING_POINTS;   //会多缓冲200个点

        //查询dma的计数值 缓冲到6400+200个字节时让其停止！！！！别多缓冲，逻辑是 dma计数值在 sig2缓冲窗口内部 时等待，缓冲到外部时就立即停止，

        if (sig2_start_point <sig2_end_point) {
            dma_index = Get_DMA_Index();
            while((sig2_start_point<=dma_index)&&(dma_index<=sig2_end_point)){
                //延时。
                dma_index = Get_DMA_Index();
            }
        }else {
            dma_index = Get_DMA_Index();
            while((sig2_start_point<=dma_index)||(dma_index<=sig2_end_point)){
                //延时。
                dma_index = Get_DMA_Index();
            }
        }

        HAL_TIM_Base_Stop_IT(&htim6);    //停止 dma 和 tim
        HAL_ADC_Stop_DMA(&hadc1);
        rt_kprintf("\nsig2 %d->%d,dma:%d\n", sig2_start_point, sig2_end_point,Get_DMA_Index());

        //3、缓冲完后，进行滤波计算和解析出 编码
        fir_u16_bp(sig2_start_point);  //滤波
        if(Sig2_Decode(&code))
        {
            /*
             * 这里还缺少 真正的本地SIG的对时，下列发送只是发送给MB板方便调试
             * */


SEND_TIME_AGAIN:
            Get_Time_8(&soe_buf[0]);  //获取时间
            rt_memcpy(&soe_buf[8], &code, 4);  //填充对时数据   ，共8+4个字节
            soe_buf[18] = 0x02;  //对时soe标志

            if(RT_EOK!= rt_mq_send(&mq_topo, soe_buf, SIZE_PER_SOE_MQ)){
               rt_mq_recv(&mq_topo, soe_buf, SIZE_PER_SOE_MQ, 0);   //消息队列已满，消费掉最旧的一条
               goto SEND_TIME_AGAIN;
            }

            rt_kprintf("decode: 0x%x\n", code);
        }

        /*if(stop_enable)
        {
           rt_kprintf("adc dma stop!\n");
           while(1){
               rt_thread_mdelay(10000);
           }
        }*/


        goto RESTART_CHECK;
}

/*  一次检测 5000个点的   前半部
 *
 */
rt_bool_t Check_FirstHalf(uint16_t *p_win1_index0)
{
    uint16_t win1_end;
    while(1)
    {
        if (Check_Win1((*p_win1_index0), ((*p_win1_index0)+WIN_1_INTERVAL))%SAMPLING_POINTS)
        {
            if(   Check_Bit2((*p_win1_index0))  ){
                return RT_TRUE;
            }
        }
        (*p_win1_index0) += WIN_1_STEP;              //起点移动
        (*p_win1_index0) %= SAMPLING_POINTS;

        win1_end = (*p_win1_index0) + WIN_1_INTERVAL + WIN_1_LEN;  //终点移动
        win1_end %= SAMPLING_POINTS;
        if (  ( 0<=(*p_win1_index0) )&&((*p_win1_index0) <5000) && (win1_end >= 5000) ) {
            return RT_FALSE;
        }
    }
}

/*  一次检测 5000个点的   后 半部
 */
rt_bool_t Check_SecondHalf(uint16_t *p_win1_index0)
{
    uint16_t win1_end;
    while(1)
    {
        if (Check_Win1((*p_win1_index0), ((*p_win1_index0)+WIN_1_INTERVAL))%SAMPLING_POINTS) {

            if(   Check_Bit2((*p_win1_index0))  ){
                return RT_TRUE;
            }
        }
        (*p_win1_index0) += WIN_1_STEP;
        (*p_win1_index0) %= SAMPLING_POINTS;

        win1_end = (*p_win1_index0) +  WIN_1_INTERVAL + WIN_1_LEN;;
        win1_end %= SAMPLING_POINTS;
        if (  ( 5000<=(*p_win1_index0) )&&((*p_win1_index0) <10000) && (win1_end < 5000) ) {
            return RT_FALSE;
        }
    }
}

/*检测数据窗1的
 * */
rt_bool_t Check_Win1(uint16_t index_0, uint16_t index_n)
{
    uint8_t i, cnt=0;
    for (i = 0; i < WIN_1_LEN; ++i) {
                                                                                                    //WIN_1_THRESOLD
        if (Diff_q15(dsp_buff[(index_0+i)%SAMPLING_POINTS], dsp_buff[(index_n+i)%SAMPLING_POINTS]) > win_1_thresold) {
            cnt ++;
        }
        if (cnt>=WIN_1_COUNT) {
            return RT_TRUE;
        }
    }
    return RT_FALSE;

}

/*    检测   第二个位 ,   类似检测    前半部和    后半部
 * */
rt_bool_t Check_Bit2(uint16_t  win1_index0)
{
    win1_index0 += 190;   //往后 大约移动190， 检测 190~210范围内有无 第二个位
    win1_index0 %= SAMPLING_POINTS;
    uint8_t i;

    for (i = 0; i < 21; ++i)
    {
        if (Check_Win1(win1_index0, (win1_index0+WIN_1_INTERVAL))%SAMPLING_POINTS) {

            return RT_TRUE;
        }
        win1_index0 += WIN_1_STEP;
        win1_index0 %= SAMPLING_POINTS;
    }
    return RT_FALSE;
}

// 求两个 q15_t数据类型 的差绝对值
q15_t Diff_q15(q15_t a, q15_t b)
{
    return ((a>b)?(a-b):(b-a));
}
//获取当前 dma缓冲位置
int16_t Get_DMA_Index()
{
    int16_t ret = SAMPLING_POINTS - __HAL_DMA_GET_COUNTER(&hdma_adc1) -1;   //-1 ~4999
    return ((ret<0)?0:ret);
}


//停止使能
long stop(int argc, char **argv)
{
    //stop_enable = RT_TRUE;
    HAL_TIM_Base_Stop_IT(&htim6);    //停止 dma 和 tim
    HAL_ADC_Stop_DMA(&hadc1);
    rt_kprintf("\ntim and adc dma stop, dma cnt:%d\n", Get_DMA_Index());
    return 0;
}
FINSH_FUNCTION_EXPORT(stop, stop receive time signal);
MSH_CMD_EXPORT(stop, stop receive time signal);
