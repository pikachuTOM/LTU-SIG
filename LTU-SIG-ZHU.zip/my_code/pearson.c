/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-18     liuwei       the first version
 */

#if 0
#include "board.h"
#include "arm_math.h"
#include "math.h"

#include "universal_api.h"
#include "filter.h"

extern q15_t fir_output[TEST_LENGTH_SAMPLES];

q15_t model[100] = {0,0,0,0,0,0,0,0,0,-24,-48,-72,-96,-120,15,150,83,16,-50,-10,30,24,18,12,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,20,30,40,50,60,70,80,90,100,33,-34,-100,-75,-50,-25,0,0,0,0,0,0,0,0,0,0,0,0,0,0
}; //model2

//model1//{-1,2,2,4,4,5,3,3,3,-1,-5,-14,-29,-82,-47,104,75,-19,-29,10,30,17,6,-3,-8,-12,-17,-18,-17,-14,-9,-4,1,8,12,16,15,14,11,7,3,-1,-5,-10,-12,-11,-13,-10,-7,-5,-2,4,5,7,11,11,11,10,7,6,5,4,1,-3,-5,-13,-12,-10,-13,-13,-10,-10,-4,-2,5,9,16,25,39,69,63,-38,-127,-108,-24,12,9,20,20,-3,-4,13,6,-6,5,28,5,-10,-6,1};

/*General Pearson product moment correlation coefficient
 * pearson 通用
 *
 */
float General_Pearson(q15_t *x, q15_t *y, uint16_t n)
{
    uint16_t i;
    double sum1, sum2, sum3, x_average, y_average;

    //该部分可以预处理 ,减少计算时间
    x_average = 0;
    for (i = 0; i < n; ++i) {
        x_average += x[i];

    }
    x_average /= n;

    sum2 = 0;
    for (i = 0; i < n; ++i) {
        sum2 += (x[i] - x_average)* (x[i] - x_average);
    }
    sum2 = sqrt(sum2);
    //

    y_average = 0;
    for (i = 0; i < n; ++i) {
        y_average += y[i];
    }
    y_average /= n;

    sum1 = 0;
    sum3 = 0;
    for (i = 0; i < n; ++i) {
        sum1 += (x[i] - x_average)* (y[i] - y_average);
        sum3 += (y[i] - y_average)* (y[i] - y_average);
    }
    sum3 = sqrt(sum3);

    return (float)(sum1 / sum2 /sum3);
#if 0
    uint16_t i;
    double sum1, sum2, sum3, x_average, y_average;

    x_average = 0;
    y_average = 0;
    for (i = 0; i < n; ++i) {
        x_average += x[i];
        y_average += y[i];
    }
    x_average /= n;
    y_average /= n;
    sum1 = 0;
    sum2 = 0;
    sum3 = 0;
    for (i = 0; i < n; ++i) {
        sum1 += (x[i] - x_average)* (y[i] - y_average);
        sum2 += (x[i] - x_average)* (x[i] - x_average);
        sum3 += (y[i] - y_average)* (y[i] - y_average);
    }

    sum2 = sqrt(sum2);
    sum3 = sqrt(sum3);
    return (float)(sum1 / sum2 /sum3);
#endif
}

/*
 * pearson 快速 ,将模板的 平均 ，方差预处理
 */
float Fast_Pearson(q15_t *data)
{


    return 0;
}


/*将滤波后的数据循环检测，解析出编码
 *
 * 数据窗 100
 * 步长20->10->5
 */
#define PEARSON_STEP   1

void Code_Analysis()
{
    uint8_t i, code[9];   //2000/20 =100  fir_output[TEST_LENGTH_SAMPLES]
    uint16_t j;
    float ret;
    //rt_kprintf("start code analysis:\n");

#if 0   //调试   相似度算法
    for (i = 0; i<(TEST_LENGTH_SAMPLES/PEARSON_STEP); ) {
        ret = General_Pearson(model, &fir_output[i*PEARSON_STEP], 100);

        if (ret >= 0.5) {
            rt_kprintf("(%d ", i);
            PrintFloat(ret);
            rt_kprintf(")");
        }
        i++;
        if ((i*PEARSON_STEP+100) >=TEST_LENGTH_SAMPLES) {
            break;
        }
    }
    rt_kprintf("\nca end\n");

#endif
#if 0   //用相似度算法找  超过门槛值的波峰
    for (i = 0; i < 9; ++i)    //暂时只考虑 9位编码
    {
        code[i] = 0;
        for (j = i*200+100-10; j < (i*200+100+60); ++j)
        {
            ret = General_Pearson(model, &fir_output[j], 100);
            if (ret >= 0.35) {
                code[i] = 1;
            }
            //PrintFloat(ret);   //打印
        }
        //rt_kprintf("\n");
    }
    rt_kprintf("\npearson uncode: ");
    for (i = 0; i < 9; ++i) {
        rt_kprintf("%d ", code[i]);
    }
    rt_kprintf("\n");
#endif

#if 1

    for (i = 0; i < 9; ++i)    //暂时只考虑 9位编码
    {
        code[i] = 0;
        for (j = i*200+100-10; j < (i*200+100+60); ++j)
        {
            if (fir_output[j] >= 100) {
                code[i] = 1;
            }
        }
    }
    rt_kprintf("uncode:");
    for (i = 0; i < 9; ++i) {
        rt_kprintf("%d ", code[i]);
    }
    rt_kprintf("\n");
    rt_hw_cpu_reset();

#endif
}




/***********cmd*******/

#if 1
//test pearson
void pearson()
{
    q15_t data[100] = {-4,0,0,0,4,3,4,6,4,1,-1,-5,-14,-28,-79,-55,100,82,-17,-32,9,29,19,6,-2,-9,-12,-15,-19,-18,-15,-11,-5,1,8,11,14,15,13,13,8,3,-2,-5,-9,-10,-11,-14,-11,-8,-5,-2,2,5,7,12,12,12,12,7,4,3,3,0,-4,-5,-9,-15,-14,-14,-13,-12,-8,-5,1,5,10,19,30,56,73,30,-83,-135,-77,2,9,12,26,14,-11,6,14,0,-5,13,24,-6,-10,-3};
    float ret;

    ret = General_Pearson(model, data, 100);

    PrintFloat(ret);
    rt_kprintf("\n");

}
FINSH_FUNCTION_EXPORT(pearson, test pearson);
MSH_CMD_EXPORT(pearson, test pearson);
#endif

#endif
