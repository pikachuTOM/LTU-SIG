/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */
#include "rtthread.h"
#include "ai.h"
#include "sig.h"
#include "board.h"
#include <arm_math.h>
#include "arm_const_structs.h"
#include "cfft.h"
#include "math.h"

extern uint8_t cfft_print_ctrl;
extern rt_bool_t is_pg;
extern RTC_HandleTypeDef hrtc;
/*
        查看当前系统时间并对时
*/
/* 手动对时  年月日周*/
long rdate(int argc, char **argv)
{
        if(1== argc){
                RTC_DateTypeDef sDate = {0};
                RTC_TimeTypeDef sTime = {0};
                HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
                HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
                rt_kprintf("%d/%d/%d/%d,",sDate.Year, sDate.Month, sDate.Date, sDate.WeekDay);
                rt_kprintf("%d:%d:%d(%dms)\n",sTime.Hours, sTime.Minutes, sTime.Seconds,(uint32_t)(sTime.SubSeconds*1000/1024+0.5));

        }else if(5 == argc){
                RTC_DateTypeDef sDate = {0};
                char *p = argv[1];
                sDate.Year = (p[0]-'0')*10 + p[1]-'0';
                p = argv[2];
                sDate.Month = (p[0]-'0')*10 + p[1]-'0';
                p = argv[3];
                sDate.Date = (p[0]-'0')*10 + p[1]-'0';
                p = argv[4];
                sDate.WeekDay = p[0]-'0';
                if((sDate.Month>12)||(sDate.Month<1)||(sDate.Date>31)||(sDate.Date<1)||(sDate.WeekDay>7)||(sDate.WeekDay<1)){
                        rt_kprintf("ResetTimeFailed,MonthWithin(1~12),DayWithin(1~31),WeekDayWithin(1~7)\n");
                        return 0;
                }
                if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
                {
                        rt_kprintf("Reset date failed\n");
                        Error_Handler();
                }
                rt_kprintf("reset date success %d/%d/%d/%d,\n",sDate.Year,sDate.Month,sDate.Date,sDate.WeekDay);
        }else{
            rt_kprintf("reset date format error.(exp: date 19 08 02 2 year month day weekday)\n");
        }
    return 0;
}
FINSH_FUNCTION_EXPORT(rdate, Reset Date);
MSH_CMD_EXPORT(rdate,Reset Date);
/*手动 对时 时分秒*/
long rtime(int argc, char **argv)
{
        if(4== argc){
                RTC_TimeTypeDef sTime = {0};
                char *p = argv[1];
                sTime.Hours = (p[0]-'0')*10 + p[1]-'0';
                p = argv[2];
                sTime.Minutes = (p[0]-'0')*10 + p[1]-'0';
                p =argv[3];
                sTime.Seconds = (p[0]-'0')*10 + p[1]-'0';

                if((sTime.Hours>59)||(sTime.Minutes>59)||(sTime.Seconds>59)){
                        rt_kprintf("Reset time failed, Hour, Minutes and Seconds within (0~59)\n");
                        return 0;
                }
                if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
                {
                        rt_kprintf("Reset time failed\n");
                        Error_Handler();
                }
                rt_kprintf("Reset time success %d:%d:%d\n",sTime.Hours,sTime.Minutes,sTime.Seconds);

        }else{
                rt_kprintf("reset time format error.(exp: resettime 10 08 59)\n");
        }
        return 0;
}
FINSH_FUNCTION_EXPORT(rtime, Reset time);
MSH_CMD_EXPORT(rtime,Reset time);



long pcfft(int argc, char **argv)
{
    if(cfft_print_ctrl){
        cfft_print_ctrl = 0;
    }else{
        cfft_print_ctrl = 1;
    }
    return 0;
}
FINSH_FUNCTION_EXPORT(pcfft, print cfft value);
MSH_CMD_EXPORT(pcfft, print cfft value);


long sig(int argc, char **argv)
{
    Sig();
    return 0;
}
FINSH_FUNCTION_EXPORT(sig, send one topo sig);
MSH_CMD_EXPORT(sig, send one topo sig);




long pg(int argc, char **argv)
{
    if (is_pg) {
        is_pg = RT_FALSE;
    }else{
        is_pg = RT_TRUE;
    }
    return 0;
}
FINSH_FUNCTION_EXPORT(pg, ce shi maichong xinhao);
MSH_CMD_EXPORT(pg, ce shi maichong xinhao);

