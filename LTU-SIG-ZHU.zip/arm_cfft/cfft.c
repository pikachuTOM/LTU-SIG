/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */

#include "board.h"
#include <arm_math.h>
#include "arm_const_structs.h"
#include "cfft.h"
#include "math.h"
#include "ai.h"

extern uint16_t adc_buf[128*10];
extern q15_t topo_value[5];
rt_bool_t enable_stop_topo_rec;
//傅里叶变换 输入输出缓冲
q15_t fft_input[512*2];  //实虚实虚存放
q15_t fft_output[512];   //求模的结果
q15_t cfft_buf[CTTT_BUF_LEN][4];   //用于缓冲幅值
uint8_t cfft_buf_index = 0;
//q15_t cfft_buffffff[110][4] = {0};

// 检测拓扑的门槛值
q15_t Frec_threshold;
q15_t Frec_threshold_2;
//cfft要检测的频点
uint16_t cfft_check_point[4];  //cfft要检测的频点


//soe控制和打印控制
//uint8_t cnt_cfft = 0, flag_cfft = 0, time_cnt=0, topo_cnt = 0;
uint16_t time_cnt = 0;
uint8_t state_topo = 0, cfft_print_ctrl = 0;
rt_bool_t is_just_rest = RT_TRUE;


/*cfft
 * 返回 0 表示检测到，1没有检测到
 * num 0 1 2...9 表示是缓存区号
 * */
uint8_t Cfft(uint8_t num)
{
    //1、处理数据，只在(实部)存放数据,并且拼接（四个周波）的数据
    memset(fft_input,0,512*2);   //这个必须有，因为 傅里叶分析函数，输入和输出 都是一个缓冲
    uint16_t i;
    num = (num - 3 + 10) % 10 ;    //指向 当前缓冲区的前三个缓冲区
    for (i = 0; i < 512; ++i) {
        fft_input[i*2] = (q15_t)(adc_buf[ (num*128 +i)%1280] -2047);
    }

    //2\cfft转换，fft_input 既是输入也是输出
    arm_cfft_q15(&arm_cfft_sR_q15_len512, fft_input, 0, 1);
    //3、求模
    cmplx_mag(fft_input, fft_output, 100);   //一般第三个参数填写 512，但是只用前39中的4个，所以改为40（39+1）

    //调试打印
    if(cfft_print_ctrl)
    {
        //rt_kprintf("%3d %3d\n",fft_output[cfft_check_point[0]], fft_output[cfft_check_point[1]]);
#if 1
        for (i = 0; i < 4; ++i)
        {
            rt_kprintf("%3d ", fft_output[cfft_check_point[i]]);
        }
        rt_kprintf("\n");
#endif
    }
    //往缓冲区中存放cfft幅值

    for (i = 0; i < 4; ++i) {
        cfft_buf[cfft_buf_index][i] = fft_output[cfft_check_point[i]];
    }
    cfft_buf_index ++;
    cfft_buf_index %= CTTT_BUF_LEN; //index指向的是下一个存储区
    //复位判断
    if (is_just_rest){
        if ((++time_cnt) >20) {
            is_just_rest = RT_FALSE;
            time_cnt = 0;
        }
        return 1;
    }


    //4、检测
    if (0== state_topo)
    {
        if(Detection_Criteria(0))
        {
            //检测到第一个频点
            time_cnt = 0;
            state_topo = 1;
            for (i = 0; i < 4; ++i)
            {
                rt_kprintf("%3d ", fft_output[cfft_check_point[i]]);
            }
            rt_kprintf("-1\n");
            //需要更新 topovalue
            if (fft_output[cfft_check_point[0]]>topo_value[0] && fft_output[cfft_check_point[1]]>topo_value[1]) {
                topo_value[0] = fft_output[cfft_check_point[0]];
                topo_value[1] = fft_output[cfft_check_point[1]];
            }
        } else
        {
            //无拓扑
        }
        return 1;
    } else if(1== state_topo)
    {
        if (time_cnt<= (TIME_BASE + Time_Deviation))
        {
            if (Detection_Criteria(1))
            {
                //未超时且检测到了第二个频点
                if (time_cnt< (TIME_BASE -Time_Deviation)) {   //太快了
                    state_topo = 0;
                    rt_kprintf("-2k %d\n", time_cnt);
                } else {             //正好

                    for (i = 0; i < 4; ++i)
                    {
                        rt_kprintf("%3d ", fft_output[cfft_check_point[i]]);
                    }
                    rt_kprintf("-2 %d\n", time_cnt);
                    time_cnt = 0;
                    state_topo = 2;

                    //需要更新topovalue
                    if (fft_output[cfft_check_point[1]]>topo_value[2] && fft_output[cfft_check_point[2]]>topo_value[3]) {
                        topo_value[2] = fft_output[cfft_check_point[1]];
                        topo_value[3] = fft_output[cfft_check_point[2]];
                    }
                }
            } else
            {
                time_cnt ++;
            }

        } else
        {
            //超时 检测失败
            time_cnt = 0;
            state_topo = 0;
        }
        return 1;

    }else if(2== state_topo)
    {
        if(time_cnt<= (TIME_BASE +Time_Deviation))
        {
            if (Detection_Criteria(2))
            {
                //未超时且检测到了第3个频点
                if (time_cnt< (TIME_BASE-Time_Deviation)) {   //太快了
                    state_topo = 0;
                    rt_kprintf("-3k %d\n", time_cnt);
                } else {             //正好

                    for (i = 0; i < 4; ++i)
                    {
                        rt_kprintf("%3d ", fft_output[cfft_check_point[i]]);
                    }
                    rt_kprintf("-3 %d\n", time_cnt);
                    time_cnt = 0;
                    state_topo = 0;
                    //需要更新topovalue
                    if (fft_output[cfft_check_point[2]]>topo_value[4] )
                    {
                        topo_value[4] = fft_output[cfft_check_point[2]];
                    }
                    return 0;
                }
            } else
            {
                time_cnt ++;
            }
        }else
        {
            //超时 检测失败
            state_topo = 0;
        }

        return 1;
    }else{
        state_topo = 0;
        return 1;
    }
    return 1;
}

//求模运算
void cmplx_mag(q15_t * pSrc, q15_t * pDst, uint16_t numSamples)
{
    q31_t acc0, acc1;
    q15_t real, imag;
      while (numSamples > 0U)
      {

        real = *pSrc++;
        imag = *pSrc++;
        acc0 = (real * real);
        acc1 = (imag * imag);

           *pDst++ = sqrtl(acc0 +acc1);
        numSamples--;
      }
}


q15_t max_q15(q15_t a, q15_t b){
    return ( (a>b)?a:b);

}
q15_t min_q15(q15_t a, q15_t b){
    return ( (a>b)?b:a);
}

/*某频点的检测判据
 *
 * state 指示当前检测哪个频点, (0) (1) (2) 3
 * */
rt_bool_t Detection_Criteria(uint8_t frec_point)
{
    uint8_t i, cnt=0;
    for (i = 0; i < WIN_LEN; ++i)
    {
        if( (cfft_buf[get_win2_start(cfft_buf_index+i)][(frec_point)%4] - cfft_buf[get_win1_start(cfft_buf_index+i)][(frec_point)%4]) >= Frec_threshold && \
            (cfft_buf[get_win2_start(cfft_buf_index+i)][(frec_point+1)%4] - cfft_buf[get_win1_start(cfft_buf_index+i)][(frec_point+1)%4]) >= Frec_threshold  &&\
            (cfft_buf[get_win2_start(cfft_buf_index+i)][(frec_point+2)%4] - cfft_buf[get_win1_start(cfft_buf_index+i)][(frec_point+2)%4]) <= Frec_threshold_2 &&\
            (cfft_buf[get_win2_start(cfft_buf_index+i)][(frec_point+3)%4] - cfft_buf[get_win1_start(cfft_buf_index+i)][(frec_point+3)%4]) <= Frec_threshold_2 ){
            if (++cnt >=2) {
                return RT_TRUE;
            }
        }
    }
    return RT_FALSE;
}





