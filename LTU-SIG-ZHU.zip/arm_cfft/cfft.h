/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-05-18     liuwei       the first version
 */
#ifndef ARM_CFFT_CFFT_H_
#define ARM_CFFT_CFFT_H_

typedef int16_t q15_t;

#define   CTTT_BUF_LEN    (10)
#define   WIN_LEN         (3)    //数据窗长度
#define   WIN_interval    (7)     //数据窗间隔
#define   get_win2_start(x)  ( (x+ CTTT_BUF_LEN - WIN_LEN)% CTTT_BUF_LEN)  //由当前位置获得第一个数据窗起点
#define   get_win1_start(x)  ( (x+ CTTT_BUF_LEN - WIN_LEN - WIN_interval)% CTTT_BUF_LEN) //由当前位置获得第二个数据窗起点


#define   TIME_BASE       (57)   //表示的是一分钟
#define   Time_Deviation  (8)   //时间误差偏差

#endif /* ARM_CFFT_CFFT_H_ */
uint8_t Cfft(uint8_t num);
void cmplx_mag(q15_t * pSrc, q15_t * pDst, uint16_t numSamples);
q15_t max_q15(q15_t a, q15_t b);
q15_t min_q15(q15_t a, q15_t b);
rt_bool_t Detection_Criteria(uint8_t frec_point);
