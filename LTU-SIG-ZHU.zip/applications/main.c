/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-09-09     RT-Thread    first version
 */

#include "board.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#include "init.h"
extern IWDG_HandleTypeDef hiwdg;

int main(void)
{

    init();

    while (1)
    {

        HAL_IWDG_Refresh(&hiwdg); //喂狗
        rt_thread_mdelay(3000);
    }

    return RT_EOK;
}
